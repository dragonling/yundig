<?php defined('SYSPATH') or die('No direct script access.');

/**
 * Backwards compatibility extension for the database writer.
 *
 * @package    Kohana/Database
 * @category   Configuration
 * @author     Kohana Team
 * @copyright  (c) 2011 Kohana Team
 * @license    http://kohanaframework.org/license
 */
class Kohana_Config_Database extends Kohana_Config_Database_Writer
{
	
}
