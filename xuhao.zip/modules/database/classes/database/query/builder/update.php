<?php defined('SYSPATH') or die('No direct script access.');

class Database_Query_Builder_Update extends Kohana_Database_Query_Builder_Update {}
