<?php defined('SYSPATH') or die('No direct script access.');

abstract class Database_Query_Builder_Where extends Kohana_Database_Query_Builder_Where {}
