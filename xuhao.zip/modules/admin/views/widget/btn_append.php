
<button class="btn" onclick="<?php echo $onclick; ?>" type="button"><span class="add"><?php echo I18n::get('btn_append', 'common')?></span></button>