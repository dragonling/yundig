<?php defined('SYSPATH') or die('No direct script access.');
/**
 *  应用管理
 *
 * @package    Kohana/Admin/App
 * @category   Controllers
 * @author     Shunnar
 */
class Controller_App_About extends Controller_Admin{
	
	function before()
	{		
		$this->model = "app_about";
		$this->title = "About 管理";			
		
		//$this->info ="";
		//$this->error = "";
		///$this->warning = "";
		//$this->success = "";
		parent::before();				
	}
	/**
	 * 改写默认表单基本信息
	 * @example
	 	parent::blank_form_columns($col,TRUE); //ID在添加时是否显示
	    $data['ext']['validate']['rules'] = '{}';
	    $data['ext']['validate']['message'] = '{}';
	    
	    // type 采用 Select 表单 数据来源于 type_options 方法
	    $data['type']['field'] = Form::select("type",$this->type_options(),1);
	    	
	 * @see Controller_Admin::blank_form_columns()
	 */
	protected function blank_form_columns($col,$return_id=FALSE)
	{
		$data = parent::blank_form_columns($col,$return_id);
		
		$data['contents']['field']  = View::factory('editor',array('field'=>'contents', 'value'=>''));
		return $data;
	}
	
	/**
	 * 改写默认表单编辑信息 基本数据继承 blank_form_columns 与 list_columns
	 * @example
	    $data = parent::full_form_columns($col,$orm);
	 	$data['type']['field'] = Form::select("type",$this->type_options(),$orm->type); //转换成Select并赋值
	 	
	 * @see Controller_Admin::full_form_columns()
	 */
	protected function full_form_columns($col,$orm=NULL)
	{
		$data = parent::full_form_columns($col,$orm);
		
		$data['contents']['field']  = View::factory('editor',array('field'=>'contents', 'value'=>$orm->contents));
		return $data;
	}
}
?>