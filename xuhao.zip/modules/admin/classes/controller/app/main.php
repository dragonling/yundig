<?php defined('SYSPATH') or die('No direct script access.');
/**
 *  应用管理
 *
 * @package    Kohana/Admin/App
 * @category   Controllers
 * @author     Shunnar
 */
class Controller_App_Main extends Controller_Admin{
	
	function before()
	{		
		$this->model = "app_main";
		$this->title = "应用管理";	
		
		//$this->info ="";
		//$this->error = "";
		///$this->warning = "";
		//$this->success = "";
		parent::before();				
	}
	/**
	 * 自定义显示列信息
	 * @see Controller_Admin::columns()
	 * @example
 	    $data =  parent::columns($data);
		$data['tid']['func'] = "md5";
		$data['tid']['name'] = "字段中文";
		$data['id']['desc'] = "字段的注释部分";
		return $cols;
	 */
	function list_columns($data)
	{
		$data =  parent::list_columns($data);
		
		$data['thumb']['func'] 		  = "image_link";
		
		$data['category_id']['func']  = "category_name";
		$data['description']['func']  = "limitstr";	
		$data['status']['func'] 	  = "status_text";	
		
		//$data['suggest']['func'] = "suggest";	
		
		unset($data['title']);		
		unset($data['image']);
		unset($data['description']);
		unset($data['contents']);
		unset($data['count']);
		
		return $data;
	}
	/**
	 * 重写修改应用列表显示方式
	 * @see Controller_Admin::action_list()
	 */
	function action_list()
	{
		$data = parent::action_list(); 
		foreach($data as $k=>$v)
		{
			$_data[$k] = $v;
			$_data[$k]->thumb = 'assets/uploads/appstore/'.$v->id.'/'.$v->thumb;
			
			
			$_data[$k]->suggest = $this->toggle('suggest',$v->id,$v->suggest);
			
		}
		$this->template->data = $_data;
	}
	
	function action_save()
	{	
		//初始化 model配置 
		$this->init();
		
		//获取 POST数据
		$data = $this->request->post();
		
		//因为需要兼容Add 与 Edit操作   为 Add操作默认pk为NULL
		$data[$this->pk] = isset($data[$this->pk]) ? $data[$this->pk] : NULL;
		
		$primary_key = $data[$this->pk];
		$orm = ORM::factory($this->model, $primary_key);
				
		//print_r($data);exit;
		//save
		foreach($this->columns as $k => $v)
		{
			$orm->$v = isset($data[$v]) ? $data[$v] : '';
		}
		$orm->save();		
		$aid = $orm->pk();
		$this->upload_file($aid);
	}
	
	function upload_file($aid)
	{
		$data = $this->request->post();
		
		$image = $data['image'];	
		$thumb = $data['thumb'];	
		
		
		$app_path = DOCROOT."/assets/uploads/appstore/".$aid;

		if(!file_exists($app_path))
		{
			mkdir($app_path,0755,TRUE);
		}
		//如果变更数据
		
		
		if(file_exists(UPLOADPATH.'/'.$thumb))
		{
			@rename(UPLOADPATH.'/'.$thumb, $app_path.'/'.$thumb);
		}
		
		if(file_exists(UPLOADPATH.'/'.$image))
		{
			@rename(UPLOADPATH.'/'.$image, $app_path.'/'.$image);
		}
		
	}
		
	/**
	 * 改写默认表单基本信息
	 * @example
	 	parent::blank_form_columns($col,TRUE); //ID在添加时是否显示
	    $data['ext']['validate']['rules'] = '{}';
	    $data['ext']['validate']['message'] = '{}';
	    
	    // type 采用 Select 表单 数据来源于 type_options 方法
	    $data['type']['field'] = Form::select("type",$this->type_options(),1);
	    	
	 * @see Controller_Admin::blank_form_columns()
	 */
	protected function blank_form_columns($col,$return_id=FALSE)
	{
		$data = parent::blank_form_columns($col,$return_id);
		
		$data['description']['name'] = '简介';
		
		//表单特殊处理
		
		$data['thumb']['field']  = View::factory('upload',array('field'=>'thumb','value'=>''));
		$data['image']['field']  = View::factory('upload',array('field'=>'image','value'=>''));
		$data['contents']['field']  = View::factory('editor',array('field'=>'contents','value'=>''));
		
			
		$data['category_id']['field']  = Form::select("category_id",$this->category_options());
		$data['description']['field']  = Form::textarea('description','',array('id'=>'description','class'=>'medium half'));
		//$data['contents']['field']	   = Form::textarea('contents','',array('id'=>'contents','class'=>'medium full'));
		
		$data['status']['field'] 	   = Form::select("status", $this->status_options(), 1);
				
		$data['suggest']['field'] = "是否推荐".Form::checkbox('suggest','1',FALSE);
		$data['suggest']['validate']['rules'] = '{}';
		$data['suggest']['validate']['message'] = '{}';
		
		unset($data['count']);
		return $data;
	}
	
	/**
	 * 改写默认表单编辑信息 基本数据继承 blank_form_columns 与 list_columns
	 * @example
	    $data = parent::full_form_columns($col,$orm);
	 	$data['type']['field'] = Form::select("type",$this->type_options(),$orm->type); //转换成Select并赋值
	 	
	 * @see Controller_Admin::full_form_columns()
	 */
	protected function full_form_columns($col,$orm=NULL)
	{
		$data = parent::full_form_columns($col,$orm);
		
		
		$data['thumb']['field'] = View::factory('upload',array('field'=>'thumb','value'=>$orm->thumb));
		$data['image']['field'] = View::factory('upload',array('field'=>'image','value'=>$orm->image));
		$data['contents']['field']  = View::factory('editor',array('field'=>'contents', 'value'=>$orm->contents));
		
		$data['category_id']['field'] = Form::select("category_id",$this->category_options(),$orm->category_id);
		
		$data['description']['field'] = Form::textarea('description',$orm->description,array('id'=>'description','class'=>'medium half'));
		//$data['contents']['field'] 	  = Form::textarea('contents',$orm->contents,array('id'=>'contents','class'=>'large full'));
		$data['suggest']['field'] = "是否推荐".Form::checkbox('suggest', 1, (bool)$orm->suggest);
		
		$data['status']['field'] 	   = Form::select("status",$this->status_options(), $orm->status);
		
		unset($data['count']);
		return $data;
	}
	
	/**
	 * 
	 * 列表静态操作方法
	 * @param primary_key $id
	 */
	public static function handle($id)
	{
		$anchor  = '<a href="./edit/'.$id.'">编辑</a> ';
		$anchor .= '<a onclick="return confirm(\'确定删除？ 删除后将无法恢复\')" href="./del/'.$id.'">删除</a> ';
		return $anchor;
	}
	
	public static function download_link($link)
	{
		return "<a href='".$link."' target='_blank'>下载</a>";
	}
	
	public static function image_link($link)
	{
		return "<a href='".Kohana::$base_url.$link."' target='_ajax'>查看图片</a>";
	}
	
	public static function category_name($cid)
	{
		$menu =  ORM::factory("app_category",$cid);
		$title = $menu->name ? $menu->name : "-";
		return $title;		 
	}
	
	public static function category_options()
	{
		$options =  DB::select('id', 'name')->from('vlc_app_category')->order_by('sort','asc')->execute()->as_array("id");
		
		foreach ($options as $k => $v)
		{
			$data[$k] = $v['name'];
		}
		return $data;
		$data = array();
		
		foreach ($options as $k => $v)
		{
			$sub_options =  DB::select('id', 'name')->from('vlc_app_category')->where('parent_id', '=', $v['id'])->order_by('sort','asc')->execute()->as_array("id");
			
			//$data[$k] = $v['name'];
			if ($sub_options)
			{
				foreach ($sub_options as $k2 => $v2)
				{
					$data[$v['name']][$k2] = $v2['name'];
				}
			}			
		}
		//ksort($options); 
		array_unshift($data, '请选择...');
		return $data;
	}
	
	/**
	 * 
	 * 限制显示字符
	 * @param unknown_type $text
	 */
	public static function limitstr($text)
	{
		return Text::limit_chars($text,15);
	}
	//状态
	public static function status_options()
	{
		return array( 0 => '回收站', 1 => '上线');
	}
	public static function status_text($id)
	{	
		$data = self::status_options();
		return $data[$id];
	}	
	
}
?>