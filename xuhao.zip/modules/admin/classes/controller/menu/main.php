<?php defined('SYSPATH') or die('No direct script access.');
/**
 *  descriptions....
 *
 * @package    Kohana/Admin
 * @category   Controllers
 * @author     Shunnar
 */
class Controller_Menu_Main extends Controller_Admin{
	
	function before()
	{
		$this->without_auth = TRUE;
		$this->_model_name = "admin_rights";
		parent::before();				
	}
	function action_sub()
	{
		$parent_id = Arr::get($_REQUEST, 'parent_id', 0);
		$menu = Common_Menu::factory($this->_model_name, 'parent_id')->sub($parent_id, 1);
		
		$data = array();
		if (Auth::instance()->get_role()->super_admin == 1)
		{
			foreach ($menu as $v)
			{
				if ($v->type == 1)
				{
					$data[$v->id]['name'] = $v->name;
					$sub_items = Common_Menu::factory($this->_model_name, 'parent_id')->sub($v->id, 1);
					
					$sub_items = Controller_Admin::bind_language($this->_model_name, $sub_items, $this->sys_language_id);
					foreach ($sub_items as $sub)
					{
						//$sub = Controller_Admin::bind_language($this->_model_name, $sub, $this->sys_language_id);
						$url_prefix = strpos($sub->right, '?') === FALSE ? '?' : '&';
						$data[$v->id]['list'][] = array(
							'current' => false,
							'title'   => $sub->name,
							'link'	  => URL::site($sub->right).$url_prefix.http_build_query(array('rs' => base64_encode($sub->id))),
							'id'	  => $sub->id,
							'target'  => $sub->target
							);
					}
				}
			}
		}
		elseif ($this->role)
		{
			$auth_roles = explode(',',	$this->role->rights);
			$auth_roles = array_flip($auth_roles);
			
			foreach ($menu as $v)
			{
				if (isset($auth_roles[$v->id]))
				{				
					if ($v->type == 1)
					{
						$data[$v->id]['name'] = $v->name;
						$sub_items = Common_Menu::factory($this->_model_name, 'parent_id')->sub($v->id, 1);
						$sub_items = Controller_Admin::bind_language($this->_model_name, $sub_items, $this->sys_language_id);
						foreach ($sub_items as $sub)
						{
							if (isset($auth_roles[$sub->id]))
							{
								$url_prefix = strpos($sub->right, '?') === FALSE ? '?' : '&';
								
								//$sub = Controller_Admin::bind_language($this->_model_name, $sub, $this->sys_language_id);
								$data[$v->id]['list'][] = array(
									'current' => false,
									'title'   => $sub->name,
									'link'	  => URL::site($sub->right).$url_prefix.http_build_query(array('rs' => base64_encode($sub->id))),
									'id'	  => $sub->id,
									'target'  => $sub->target
									);
							}
						}
					}
				}
			}
		}
		die(json_encode($data));
	}
	/**
	 * 自定义显示列信息
	 * @see Controller_Admin::columns()
	 * @example
 	    $data =  parent::columns($data);
		$data['tid']['func'] = "md5";
		$data['tid']['name'] = "字段中文";
		return $cols;
	 */
	function list_columns($data)
	{
		$data =  parent::list_columns($data);		
		
		$data['parent_id']['func'] = "menu_name";	
		$data['link']['func'] = "limitstr";	

		return $data;
	}
	protected function full_form_columns($col,$orm=NULL)
	{
		$data = parent::full_form_columns($col,$orm);		
		$data['parent_id']['field'] = Form::select("parent_id",$this->menu_options(),$orm->parent_id);
		$data['target']['field'] = Form::select("target",$this->target_options(),$orm->target);
		return $data;
	}
	protected function blank_form_columns($col,$return_id=FALSE)
	{
		$data = parent::blank_form_columns($col,$return_id);
		$data['parent_id']['field'] = Form::select("parent_id",$this->menu_options());
		$data['target']['field'] = Form::select("target",$this->target_options());
		return $data;
	}
	/**
	 * 
	 * 获取表单下拉列表数据
	 */
	private function menu_options()
	{
		
		$options =  DB::select('id', 'title')->from('admin_menu')->execute()->as_array("id","title");
		$options[0] = "顶级菜单";
		ksort($options); 
		return $options;
		
	}
	public static function menu_name($id)
	{
		if($id===NULL)
		return NULL;
		$menu =  ORM::factory("menu",$id);
		$title = $menu->title?$menu->title:"-";
		return $title;		 
	}
	public function target_options()
	{
		return  array('_self'=>'当前窗口',"_blank"=>'新窗口','_ajax'=>'Ajax','_iframe'=>'网页框架');
	}
	/**
	 * 
	 * 限制显示字符
	 * @param unknown_type $text
	 */
	public static function limitstr($text)
	{
		return Text::limit_chars($text,30);
	}
	
}
?>