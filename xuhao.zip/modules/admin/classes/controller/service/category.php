<?php defined('SYSPATH') or die('No direct script access.');
/**
 *  应用管理
 *
 * @package    Kohana/Admin/App
 * @category   Controllers
 * @author     Shunnar
 */
class Controller_Service_Category extends Controller_Admin{
	
	function before()
	{		
		$this->model = "service_category";
		$this->title = "分类管理";	
		$this->upload_path = "assets/uploads/appstore";
		
		//$this->info ="";
		//$this->error = "";
		///$this->warning = "";
		//$this->success = "";
		parent::before();				
	}
	/**
	 * 自定义显示列信息
	 * @see Controller_Admin::columns()
	 * @example
 	    $data =  parent::columns($data);
		$data['tid']['func'] = "md5";
		$data['tid']['name'] = "字段中文";
		$data['id']['desc'] = "字段的注释部分";
		return $cols;
	 */
	function list_columns($data)
	{
		$data = parent::list_columns($data);
		//$data['image']['func']     = "image_link";
		//$data['parent_id']['func'] = "type_name"; 
		
		unset($data['parent_id']);
		unset($data['image']);
		return $data;	
	}
	/*
	function action_list()
	{
		$data = parent::action_list(); 
		
		foreach($data as $k=>$v)
		{
			$_data[$k] = $v;
			$_data[$k]->image = $this->upload_path.'/'.$v->image;
		}
		$this->template->data = $_data;
	}
	*/
	function action_save()
	{
		parent::action_save();
		//$data = $this->request->post();
		//$image = $data['image'];
		//$app_path = DOCROOT.'/'.$this->upload_path.'/';
		/*
		if(!file_exists($app_path))
		{
			mkdir($app_path, 0755, TRUE);
		}
		//如果变更数据
		if(file_exists(UPLOADPATH.'/'.$image))
		{
			@rename(UPLOADPATH.'/'.$image, $app_path.$image);
		}
		*/		
	}
	
	/**
	 * 改写默认表单基本信息
	 * @example
	 	parent::blank_form_columns($col,TRUE); //ID在添加时是否显示
	    $data['ext']['validate']['rules'] = '{}';
	    $data['ext']['validate']['message'] = '{}';
	    
	    // type 采用 Select 表单 数据来源于 type_options 方法
	    $data['type']['field'] = Form::select("type",$this->type_options(),1);
	    	
	 * @see Controller_Admin::blank_form_columns()
	 */
	protected function blank_form_columns($col,$return_id=FALSE)
	{
		$data = parent::blank_form_columns($col,$return_id);
		unset($data['parent_id']);
		unset($data['image']);
		//$data['parent_id']['field'] = Form::select("parent_id", $this->parent_options(),1);
		//$data['image']['field'] = View::factory('upload',array('field'=>'image', 'value'=> ''));
		return $data;		
	}
	
	/**
	 * 改写默认表单编辑信息 基本数据继承 blank_form_columns 与 list_columns
	 * @example
	    $data = parent::full_form_columns($col,$orm);
	 	$data['type']['field'] = Form::select("type",$this->type_options(),$orm->type); //转换成Select并赋值
	 	
	 * @see Controller_Admin::full_form_columns()
	 */
	protected function full_form_columns($col,$orm=NULL)
	{
		$data =  parent::full_form_columns($col,$orm);
		
		unset($data['parent_id']);
		unset($data['image']);
		//$data['parent_id']['field'] = Form::select("parent_id", $this->parent_options(), $orm->parent_id); 
		//$data['image']['field'] = View::factory('upload',array('field'=>'image', 'value'=>$orm->image));
		return $data;	
	}
	
	public static function image_link($link)
	{
		return "<a href='".Kohana::$base_url.$link."' target='_ajax'>查看图片</a>";
	}
	/**
	 * 
	 * 返回option 选项
	 */
	public static function parent_options()
	{
		$options =  DB::select('id', 'name')->from('vlc_app_category')->where('parent_id', '=', '0')->order_by('sort','asc')->execute()->as_array("id");
		$data = array( 0 => '顶级分类');
		
		foreach ($options as $k => $v)
		{
			$data[$k] = $v['name'];	
		}
		
		//ksort($options); 
		return $data;
	}
	/**
	 * 
	 * Enter description here ...
	 * @param unknown_type $id
	 */
	public static function type_name($id)
	{
		if(empty($id)) return NULL;
		
		$data = Controller_App_Category::parent_options();
		return isset($data[$id]) ? $data[$id] : '';
	}
	
}
?>