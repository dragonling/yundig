<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * Customer
 *
 * @package    Model
 * @author     Shunnar
 * @copyright  (c) 2008-2011 Vlc dev Team
 */
 class Model_Article_Contents extends ORM {
 
	protected $_table_name = 'article_contents';
	
	protected $_primary_key = 'id';
	
 }