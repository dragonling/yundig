<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * Taobao_Items
 *
 * @package    Model
 * @author     Dragon
 * @copyright  (c) 2012-2012 Kona dev Team
 */
 class Model_Taobao_Items extends ORM {
 
	protected $_table_name = 'taobao_items';
	
	protected $_primary_key = 'id';
	
	public    $many_language = false;
 }