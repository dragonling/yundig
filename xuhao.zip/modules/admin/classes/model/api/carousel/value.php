<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * Carousel
 *
 * @package    Model
 * @author     Dragon
 * @copyright  (c) 2008-2011 Vlc dev Team
 */
 class Model_Api_Carousel_Value extends ORM {
 
	protected $_table_name = 'api_carousel_value';
	
	protected $_primary_key = 'id';
	
 }