<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * Carousel
 *
 * @package    Model
 * @author     Dragon
 * @copyright  (c) 2008-2011 Vlc dev Team
 */
 class Model_Api_Carousel extends ORM {
 
	protected $_table_name = 'api_carousel';
	
	protected $_primary_key = 'id';
	
 }