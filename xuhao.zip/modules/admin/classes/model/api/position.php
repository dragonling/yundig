<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * 广告位模型
 *
 * @package    Model
 * @author     Shunnar
 * @copyright  (c) 2008-2011 Vlc dev Team
 */
 class Model_API_Position extends ORM {
 
	protected $_table_name = 'api_ad_position';
	
	protected $_primary_key = 'id';
 }