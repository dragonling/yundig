<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * 广告模型
 *
 * @package    Model
 * @author     Shunnar
 * @copyright  (c) 2008-2011 Vlc dev Team
 */
 class Model_API_Ad extends ORM {
 
	protected $_table_name = 'api_ad';
	
	protected $_primary_key = 'id';
 }