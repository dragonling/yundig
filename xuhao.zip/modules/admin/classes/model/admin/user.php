<?php defined('SYSPATH') or die('No direct access allowed.');
/**
 * admin user menu
 *
 * @package    Admin/menu
 * @author     Shunnar
 * @copyright  (c) 2008-2011 Vlc dev Team
 */
 class Model_Admin_User extends ORM {
 
	protected $_table_name = 'admin_users';
	
	protected $_primary_key = 'id';
	
	protected $_callbacks = array(    'username' => array('username_unique'),);
 }