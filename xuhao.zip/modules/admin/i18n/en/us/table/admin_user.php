<?php defined('SYSPATH') or die('No direct script access.');

	//---------- 管理员表 ----------//
	$_lang['id']     = 'ID';
	$_lang['role_id'] = 'Role';
	$_lang['email']     = 'Email';
	$_lang['username']   = 'Username ';
	$_lang['password']      = 'Password ';
	$_lang['status']     = 'Status ';
	$_lang['logins']   = 'Logins ';
	$_lang['last_login']     = 'Last Login';
	
	$_lang['reset_token']     = 'Reset Token';
	$_lang['last_failed_login']    = 'Last Failed Login';
	$_lang['failed_login_count']     = 'Failed Logins';
	$_lang['created']     = 'Created ';
	$_lang['modified']     = 'Modified ';
	
	
	return $_lang;