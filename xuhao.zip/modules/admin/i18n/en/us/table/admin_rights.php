<?php defined('SYSPATH') or die('No direct script access.');

	//---------- 权限资源集 ----------//
	$_lang['right_name']     = 'Right Name';
	$_lang['parent_section'] = 'Parent';
	$_lang['right_type']     = 'Right Type';
	$_lang['right_status']   = 'Status';
	$_lang['text_sort']      = 'Sort Order';
	$_lang['right_sets']     = 'Rights Set';
	$_lang['right_append']   = 'Append';
	$_lang['right_code']     = 'Right Code';
	
	$_lang['data_types']     = array(1 => 'Dir', 2 => 'List', 3 => 'Ctrl');
	$_lang['data_status']    = array(0 => 'Stop', 1 => 'Start');
	
	
	return $_lang;