<?php defined('SYSPATH') or die('No direct script access.');

	//---------- 文字信息 ----------//
	$_lang['text_no_reply']       = '<b style="color:red">未回复！</b>';
	$_lang['text_already_reply']  = '已回复！';
	
	$_lang['data_article_types']   = array( 'base' => '基本', 'seo' => 'SEO设置');
	$_lang['data_product_types']   = array( 'base' => '基本', 'desc' => '描述', 'seo' => 'SEO设置', 'other' => '其它');
	
	return $_lang;