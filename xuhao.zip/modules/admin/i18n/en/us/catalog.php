<?php defined('SYSPATH') or die('No direct script access.');

	$_lang['column_extend']    = '关联';
	$_lang['btn_pick_article'] = '文章(:count)';
	$_lang['btn_pick_product'] = '商品(:count)';
	
	$_lang['data_catalog_types']   = array( 'base' => '基本', 'seo' => 'SEO设置');
	
	
	return $_lang;