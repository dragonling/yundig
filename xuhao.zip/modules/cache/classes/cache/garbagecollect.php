<?php defined('SYSPATH') or die('No direct script access.');

interface Cache_GarbageCollect extends Kohana_Cache_GarbageCollect {}