<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Sae_Memcache extends Kohana_Cache_Sae_Memcache {}