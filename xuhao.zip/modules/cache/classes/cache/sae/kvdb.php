<?php defined('SYSPATH') or die('No direct script access.');

class Cache_Sae_KVDB extends Kohana_Cache_Sae_KVDB {}