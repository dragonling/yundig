-- phpMyAdmin SQL Dump
-- version 3.4.8
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2013 年 03 月 22 日 00:45
-- 服务器版本: 5.1.60
-- PHP 版本: 5.3.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `db_clubone`
--

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_rights`
--

CREATE TABLE IF NOT EXISTS `ko_admin_rights` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `parent_id` smallint(6) NOT NULL COMMENT '父ID',
  `catalog_id` smallint(6) NOT NULL DEFAULT '0' COMMENT '目录',
  `name` varchar(20) NOT NULL COMMENT '权限树名',
  `right` varchar(100) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL COMMENT '权限',
  `type` tinyint(2) NOT NULL DEFAULT '1' COMMENT '1:目录节点  2:列表  3:操作',
  `target` char(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL COMMENT '打开位置',
  `sort_order` varchar(20) CHARACTER SET latin1 COLLATE latin1_bin NOT NULL COMMENT '排序',
  `status` tinyint(2) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=88 ;

--
-- 转存表中的数据 `ko_admin_rights`
--

INSERT INTO `ko_admin_rights` (`id`, `parent_id`, `catalog_id`, `name`, `right`, `type`, `target`, `sort_order`, `status`) VALUES
(1, 0, 0, '系统', '', 1, '', '70', 1),
(2, 1, 0, '权限管理', '', 1, '', '', 1),
(3, 2, 0, '管理员', 'admin/system/user', 2, '', '', 1),
(4, 2, 0, '角色', 'admin/system/role', 2, '', '', 1),
(5, 2, 0, '权限资源', 'admin/system/rights/list', 2, '', '', 1),
(6, 0, 0, '工具', 'javascript:;', 1, '', '80', 1),
(7, 6, 0, '文章管理', '', 1, '', '', 1),
(8, 7, 0, '文章列表', '', 2, '', '', 1),
(13, 0, 0, '網站主頁', '', 1, '', '', 1),
(15, 13, 0, '主頁內容', '', 1, '', '', 1),
(16, 15, 0, '滾動公告', '', 2, '', '', 1),
(17, 15, 0, '焦點輪播', 'admin/api/carouselvalue/list/2', 3, '', '', 1),
(18, 15, 0, '模型列表', '', 2, '', '', 1),
(19, 13, 9, '主頁欄目', 'admin/cms/main/list', 1, '', '', 1),
(22, 15, 0, '属性列表', '', 2, '', '', 1),
(23, 0, 3, '婚宴', 'admin/cms/main/list', 1, '', '', 1),
(25, 0, 1, '进销存', 'admin/cms/main/list', 1, '', '50', 1),
(28, 1, 0, '功能设置', '', 1, '', '', 1),
(29, 28, 0, '清除缓存', 'admin/cache/main', 2, '', '', 1),
(33, 7, 0, '添加文章', '', 3, '', '', 1),
(34, 22, 0, '添加', 'admin/system/right/list', 3, '', '', 1),
(35, 28, 0, '语系设定', 'admin/system/language', 2, '', '', 1),
(37, 5, 0, '新增', 'admin/system/rights/add', 3, '', '', 1),
(38, 5, 0, '编辑', 'admin/system/rights/edit', 3, '', '', 1),
(39, 28, 0, '系统设置', 'admin/system/setting/edit', 2, '', '', 1),
(40, 0, 3, '佳肴', 'admin/cms/main/list', 1, '', '', 1),
(41, 40, 0, 'CMS', '', 1, '', '', 1),
(42, 41, 0, '文章管理', 'admin/cms/main', 2, '', '', 1),
(43, 41, 5, '新闻中心', 'admin/cms/main/list/5', 1, '', '', 1),
(44, 40, 0, '产品', '', 1, '', '', 1),
(45, 40, 0, '人才招聘', '', 1, '', '', 1),
(46, 41, 0, '联系我们', 'admin/cms/main/list/6', 1, '', '', 1),
(47, 40, 0, '首页', '', 1, '', '0', 1),
(48, 40, 0, '系统', '', 1, '', '', 1),
(49, 6, 0, '广告', '', 1, '', '', 1),
(50, 49, 0, '广告管理', 'admin/api/ad/list', 2, '', '', 1),
(51, 49, 0, '广告位管理', 'admin/api/position/list', 2, '', '', 1),
(52, 50, 0, '新增', 'admin/api/ad/add', 3, '', '', 1),
(53, 50, 0, '编辑', 'admin/api/ad/edit', 3, '', '', 1),
(54, 51, 0, '新增', 'admin/api/position/add', 3, '', '', 1),
(55, 51, 0, '编辑', 'admin/api/position/edit', 3, '', '', 1),
(56, 6, 0, '小工具', '', 1, '', '', 1),
(58, 0, 3, '宴會', 'admin/cms/main/list', 1, '', '', 1),
(59, 56, 0, '文档管理', 'admin/files/main', 2, '', '', 1),
(61, 48, 0, 'CMS分类', 'admin/cms/category', 2, '', '', 1),
(63, 41, 0, '服务', 'admin/cms/main/list/3', 2, '', '', 1),
(64, 41, 0, '案例', 'admin/cms/main/list/4', 2, '', '', 1),
(65, 64, 0, '新增', 'admin/cms/main/add/4', 3, '', '', 1),
(66, 42, 0, '新增', 'admin/cms/main/save', 3, '', '', 1),
(67, 42, 0, '编辑', 'admin/cms/main/edit', 3, '', '', 1),
(70, 42, 0, '删除', 'admin/cms/main/del', 3, '', '', 1),
(71, 4, 0, 'edit', 'admin/system/rights/get_names,admin/system/role/edit,admin/system/rights/select_list', 3, '', '', 1),
(73, 41, 0, '网站栏目', 'admin/system/catalog', 2, '', '', 1),
(77, 28, 0, '模板管理', 'admin/system/theme/index', 2, '', '', 1),
(78, 41, 0, '留言反馈', 'admin/cms/feeback', 2, '', '', 1),
(79, 41, 0, '友情链接', 'admin/cms/friendlylinks', 2, '', '', 1),
(80, 44, 0, '产品管理', 'admin/product/main/', 2, '', '', 1),
(81, 44, 0, '产品分类', 'admin/product/category/', 2, '', '', 1),
(82, 39, 0, '保存', 'admin/system/setting/save', 3, '', '', 1),
(83, 73, 0, '文章', 'admin/cms/catalog', 2, '', '', 1),
(84, 73, 0, '产品', 'admin/product/catalog', 2, '', '', 1),
(86, 56, 0, '轮播', 'admin/api/carousel', 2, '', '', 1),
(87, 83, 0, '列表', 'admin/cms/catalog/list', 2, '', '', 1);

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_rights_language`
--

CREATE TABLE IF NOT EXISTS `ko_admin_rights_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `rights_id` int(11) NOT NULL,
  `language_id` smallint(6) NOT NULL,
  `name` varchar(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rights_id` (`rights_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=43 ;

--
-- 转存表中的数据 `ko_admin_rights_language`
--

INSERT INTO `ko_admin_rights_language` (`id`, `rights_id`, `language_id`, `name`) VALUES
(1, 1, 1, 'System'),
(2, 13, 1, 'Product'),
(3, 15, 1, 'Category'),
(4, 13, 2, '產品'),
(5, 15, 2, '類目管理2'),
(7, 34, 1, 'add'),
(17, 17, 1, 'Add Category'),
(34, 34, 2, '编辑'),
(35, 7, 1, 'Add'),
(36, 17, 2, '增加类别'),
(37, 22, 2, '屬性列表'),
(38, 22, 1, 'Attributes'),
(39, 21, 2, '新增商品tw'),
(40, 2, 1, '权限管理2'),
(41, 16, 1, '分类列表'),
(42, 42, 1, '公司简介');

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_roles`
--

CREATE TABLE IF NOT EXISTS `ko_admin_roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `parent_id` int(11) NOT NULL DEFAULT '0' COMMENT '上级',
  `super_admin` tinyint(2) NOT NULL COMMENT '超级管理员',
  `name` varchar(32) NOT NULL COMMENT '角色名',
  `description` varchar(255) NOT NULL COMMENT '描述',
  `rights` text NOT NULL COMMENT '权限集',
  `sort_order` varchar(20) NOT NULL COMMENT '排序',
  `status` tinyint(2) NOT NULL DEFAULT '1' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `ko_admin_roles`
--

INSERT INTO `ko_admin_roles` (`id`, `parent_id`, `super_admin`, `name`, `description`, `rights`, `sort_order`, `status`) VALUES
(1, 0, 1, '超级管理员', '超级管理员', '13,15,16,17,18,22,34,19,21,23,40,41,42,66,67,69,43,63,44,45,64,65,46,48,47,58,25,1,2,3,4,5,37,38,28,29,35,39,61,6,7,8,33,49,50,52,53,51,54,55,56,59,', '0', 1),
(2, 0, 0, '管理员', 'Administrative user, has access to everything.', '40,41,42,66,67,70,73,83,84,78,79,44,80,81,1,2,3,4,71,28,29,39,82,6,49,50,52,53,51,54,55,56,59,', '10', 1),
(4, 0, 1, '测试员', '测试员', '1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16', '0', 1),
(6, 0, 0, '编辑', 'asdf', '', '0', 1);

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_roles_language`
--

CREATE TABLE IF NOT EXISTS `ko_admin_roles_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `roles_id` int(11) NOT NULL,
  `language_id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `description` text NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_id` (`roles_id`,`language_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `ko_admin_roles_language`
--

INSERT INTO `ko_admin_roles_language` (`id`, `roles_id`, `language_id`, `name`, `description`) VALUES
(1, 4, 1, 'tests3', '測試的角色'),
(2, 4, 2, '測試', '測試的角色'),
(3, 1, 2, '超級管理員', ''),
(4, 1, 1, 'Super Admin', 'Login privileges, granted after account confirmation'),
(5, 2, 1, '管理员', 'Administrative user, has access to everything.');

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_roles_users`
--

CREATE TABLE IF NOT EXISTS `ko_admin_roles_users` (
  `admin_user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`admin_user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ko_admin_roles_users`
--

INSERT INTO `ko_admin_roles_users` (`admin_user_id`, `role_id`) VALUES
(1, 1),
(1, 2);

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_users`
--

CREATE TABLE IF NOT EXISTS `ko_admin_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `role_id` int(11) NOT NULL DEFAULT '0' COMMENT '角色',
  `email` varchar(127) NOT NULL COMMENT 'Email',
  `username` varchar(32) NOT NULL COMMENT '用户名',
  `password` char(64) NOT NULL COMMENT '密码',
  `status` varchar(20) NOT NULL COMMENT '状态',
  `logins` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录次数',
  `last_login` int(10) unsigned DEFAULT NULL COMMENT '最后登录',
  `reset_token` char(64) NOT NULL COMMENT 'Token',
  `last_failed_login` datetime NOT NULL COMMENT '最后登录失败',
  `failed_login_count` int(11) NOT NULL DEFAULT '0' COMMENT '登录失败次数',
  `created` datetime NOT NULL COMMENT '创建时间',
  `modified` datetime NOT NULL COMMENT '修改时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=9 ;

--
-- 转存表中的数据 `ko_admin_users`
--

INSERT INTO `ko_admin_users` (`id`, `role_id`, `email`, `username`, `password`, `status`, `logins`, `last_login`, `reset_token`, `last_failed_login`, `failed_login_count`, `created`, `modified`) VALUES
(1, 1, 'dragonling@live.cn', 'admin', 'bc5df3c3b1f0904df197acfd73863e868826d9b1f8f0b6ed557be1d9eeca22fa', '1', 346, 1363714986, '', '2011-11-20 04:34:58', 7, '2011-11-20 03:18:32', '2011-11-20 04:34:58'),
(2, 2, '275986776@qq.com', 'dragon', 'bc5df3c3b1f0904df197acfd73863e868826d9b1f8f0b6ed557be1d9eeca22fa', '1', 17, 1350628492, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(3, 4, 'ff@ff.com', 'fashion', '69782b89a114d098a00a4b78d231ffcea5519a5bfb90e3ac4fc92f31b6842054', '1', 3, 1343620011, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 2, 'test@tt.com', 'test', 'bc5df3c3b1f0904df197acfd73863e868826d9b1f8f0b6ed557be1d9eeca22fa', '1', 10, 1358732579, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 6, 'flling@vlctech.com', 'flling', 'bc5df3c3b1f0904df197acfd73863e868826d9b1f8f0b6ed557be1d9eeca22fa', '1', 0, NULL, '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_user_identities`
--

CREATE TABLE IF NOT EXISTS `ko_admin_user_identities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `provider` varchar(255) NOT NULL,
  `identity` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_indentity` (`provider`,`identity`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ko_admin_user_tokens`
--

CREATE TABLE IF NOT EXISTS `ko_admin_user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `admin_user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`admin_user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

--
-- 转存表中的数据 `ko_admin_user_tokens`
--

INSERT INTO `ko_admin_user_tokens` (`id`, `admin_user_id`, `user_agent`, `token`, `created`, `expires`) VALUES
(15, 1, 'b29e81af2579300ee0242b9eb66ac9bf9948f798', '1b8196e5187de8ac8b67389e2e910648c640b707', 0, 1359333478),
(14, 1, '3dac7a31e9cf4e26a53cb52348abe67cc7f52fec', '0c3fb20ef82805397ceadcf8c4d50ac23c747ee7', 0, 1359101468);

-- --------------------------------------------------------

--
-- 表的结构 `ko_api_ad`
--

CREATE TABLE IF NOT EXISTS `ko_api_ad` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `position_id` int(11) DEFAULT NULL COMMENT '所属广告位',
  `title` varchar(20) DEFAULT NULL COMMENT '广告标题',
  `type` varchar(50) DEFAULT NULL COMMENT '广告类型',
  `content` varchar(100) DEFAULT NULL COMMENT '广告内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=11 ;

--
-- 转存表中的数据 `ko_api_ad`
--

INSERT INTO `ko_api_ad` (`id`, `position_id`, `title`, `type`, `content`) VALUES
(9, 2, 'BB', 'text', 'asfasdf'),
(10, 2, '宝贝推荐', 'html', 'asdfas');

-- --------------------------------------------------------

--
-- 表的结构 `ko_api_ad_position`
--

CREATE TABLE IF NOT EXISTS `ko_api_ad_position` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT '广告位ID',
  `title` varchar(50) DEFAULT NULL COMMENT '广告位名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `ko_api_ad_position`
--

INSERT INTO `ko_api_ad_position` (`id`, `title`) VALUES
(2, '首页广告位一');

-- --------------------------------------------------------

--
-- 表的结构 `ko_api_carousel`
--

CREATE TABLE IF NOT EXISTS `ko_api_carousel` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `status` tinyint(2) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `ko_api_carousel`
--

INSERT INTO `ko_api_carousel` (`id`, `title`, `status`) VALUES
(1, '图片轮播', 1);

-- --------------------------------------------------------

--
-- 表的结构 `ko_api_carousel_value`
--

CREATE TABLE IF NOT EXISTS `ko_api_carousel_value` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `group_id` smallint(6) DEFAULT NULL COMMENT '组ID',
  `image` varchar(200) DEFAULT NULL COMMENT '大图',
  `thumb` varchar(200) DEFAULT NULL COMMENT '小图',
  `link` varchar(200) DEFAULT '' COMMENT '超链接',
  `title` varchar(100) DEFAULT NULL COMMENT '标题',
  `desc` text COMMENT '内容',
  `sort_order` smallint(6) NOT NULL DEFAULT '5' COMMENT '排序',
  `status` tinyint(2) DEFAULT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `ko_api_carousel_value`
--

INSERT INTO `ko_api_carousel_value` (`id`, `group_id`, `image`, `thumb`, `link`, `title`, `desc`, `sort_order`, `status`) VALUES
(1, 1, 'http://web.qunhe.com/images/case_banner.jpg', '', '/admin/videos/recommend/type', '', '', 0, 1),
(2, 1, 'http://web.qunhe.com/images/news_title.jpg', '', '', '', '', 0, 1),
(3, 1, 'http://web.qunhe.com/images/services_banner.jpg', '', '', '', '', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `ko_article`
--

CREATE TABLE IF NOT EXISTS `ko_article` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category_id` smallint(6) NOT NULL COMMENT '分类',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `thumb` varchar(100) NOT NULL DEFAULT '' COMMENT '缩略图',
  `images` text NOT NULL COMMENT '图片',
  `post_time` int(11) NOT NULL COMMENT '发布时间',
  `sort_order` int(11) NOT NULL COMMENT '排序',
  `status` tinyint(2) NOT NULL COMMENT '状态',
  `template` varchar(100) NOT NULL COMMENT '模板',
  `rewrite_url` varchar(100) NOT NULL COMMENT 'URL重写',
  `seo_title` varchar(100) NOT NULL COMMENT 'SEO标题',
  `seo_keywords` varchar(200) NOT NULL COMMENT '关键词',
  `seo_description` varchar(250) NOT NULL COMMENT '简述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='文章主题表' AUTO_INCREMENT=22 ;

--
-- 转存表中的数据 `ko_article`
--

INSERT INTO `ko_article` (`id`, `category_id`, `title`, `thumb`, `images`, `post_time`, `sort_order`, `status`, `template`, `rewrite_url`, `seo_title`, `seo_keywords`, `seo_description`) VALUES
(3, 2, 'About Us', 'http://web.qunhe.com/images/about_rightpc.jpg', '', 2013, 0, 1, '', '', '', '222', 'hkjhkj'),
(4, 3, '网站建设', '/assets/uploads/article/201302/2b04df3ecc1d94afddff082d139c6f15.jpg', '', 1357922431, 10, 1, '', '', '', '222', 'ssss'),
(5, 1, 'Contact', '', '', 1357922431, 0, 1, '', '', '', '', ''),
(13, 3, 'llll', '', '', 1361645817, 0, 1, '', '', '', '', ''),
(2, 2, '11', '', 'bf006e4f4109e7768e809b20f6f405ef.jpg,6d8d9608b0270b316eca847aed208449.jpg,446e50b100886f527d06e1add4bcf3cf.jpg,', 2013, 1, 1, '', '', '', '0000', 'ssss'),
(6, 1, 'News', '/assets/uploads/article/201302/9d377b10ce778c4938b3c7e2c63a229a.jpg', '', 1357922431, 0, 1, '', 'News', '云顶网络服务内容', '', ''),
(7, 3, 'Services', '', '', 1357922431, 0, 1, '', '', '', '', ''),
(8, 4, 'Cases', '', '', 1357922431, 0, 1, '', '', '', '', ''),
(9, 4, '江西中易软件官方网站建设', 'http://www.mcpinpai.com/cache/201212211994273655-195-160.jpg', '', 1361601060, 0, 1, '', '', '', '', ''),
(10, 3, '商城网店型', 'http://www.mcpinpai.com/images/tao1.jpg', '', 2013, 0, 1, '', '', '', '', ''),
(11, 5, '谷歌更新搜索算法 自动检测排除停放的域名', '', '', 2013, 0, 1, '', '', '', '', ''),
(12, 1, '江西中易软件官方网站建设kk', '', '', 1361601060, 0, 1, '', '', '', '', ''),
(14, 5, '本站上线', '', '', 1361714114, 0, 1, '', '', '', '', ''),
(17, 10, '江西中易软件官方网站建设1', '', '', 1361714661, 0, 1, '', '', '', '', ''),
(18, 11, 'UI teste', '', '', 1361718652, 0, 1, '', '', '', '', ''),
(19, 11, 'photo2', '', '', 1361718748, 0, 1, '', '', '', '', ''),
(21, 10, '网站建设', '', '', 1363365893, 0, 1, '', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `ko_article_catalog`
--

CREATE TABLE IF NOT EXISTS `ko_article_catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `article_id` int(11) NOT NULL COMMENT '文章ID',
  `catalog_id` smallint(6) NOT NULL COMMENT '栏目ID',
  `sort_order` int(11) NOT NULL DEFAULT '99',
  PRIMARY KEY (`id`),
  UNIQUE KEY `article_id` (`article_id`,`catalog_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=82 ;

--
-- 转存表中的数据 `ko_article_catalog`
--

INSERT INTO `ko_article_catalog` (`id`, `article_id`, `catalog_id`, `sort_order`) VALUES
(1, 1, 2, 99),
(2, 3, 2, 1),
(19, 4, 2, 99),
(20, 5, 2, 99),
(18, 2, 2, 99),
(43, 6, 3, 8),
(21, 6, 2, 99),
(22, 7, 2, 99),
(42, 2, 3, 99),
(40, 3, 3, 99),
(41, 4, 3, 99),
(32, 1, 3, 99),
(46, 1, 10, 99),
(48, 4, 10, 99),
(78, 18, 11, 99),
(77, 18, 1, 99),
(52, 7, 10, 99),
(53, 8, 10, 99),
(54, 9, 10, 99),
(55, 10, 10, 99),
(56, 2, 5, 99),
(57, 3, 4, 99),
(58, 4, 4, 99),
(59, 5, 4, 99),
(60, 2, 4, 99),
(61, 6, 4, 99),
(62, 7, 4, 99),
(63, 8, 4, 99),
(64, 9, 4, 99),
(65, 10, 4, 99),
(66, 3, 5, 99),
(67, 4, 5, 99),
(68, 5, 5, 99),
(69, 6, 5, 99),
(70, 7, 5, 99),
(71, 8, 5, 99),
(72, 9, 5, 99),
(73, 10, 5, 99),
(74, 11, 5, 99),
(75, 17, 1, 99),
(80, 20, 10, 99),
(81, 21, 10, 99);

-- --------------------------------------------------------

--
-- 表的结构 `ko_article_category`
--

CREATE TABLE IF NOT EXISTS `ko_article_category` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `sort_order` smallint(6) NOT NULL COMMENT '排序',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `ko_article_category`
--

INSERT INTO `ko_article_category` (`id`, `title`, `sort_order`, `status`) VALUES
(1, '公司简介', 1, 1),
(2, '新闻', 1, 1),
(3, '招聘', 1, 1);

-- --------------------------------------------------------

--
-- 表的结构 `ko_article_category_language`
--

CREATE TABLE IF NOT EXISTS `ko_article_category_language` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category_id` smallint(6) NOT NULL COMMENT '分类ID',
  `language_id` smallint(6) NOT NULL COMMENT '语系ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ko_article_contents`
--

CREATE TABLE IF NOT EXISTS `ko_article_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `article_id` int(11) NOT NULL COMMENT '主贴',
  `language_id` smallint(6) NOT NULL COMMENT '语系ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `image` varchar(100) NOT NULL COMMENT '图片',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=31 ;

--
-- 转存表中的数据 `ko_article_contents`
--

INSERT INTO `ko_article_contents` (`id`, `article_id`, `language_id`, `title`, `image`, `content`) VALUES
(2, 2, 0, 'New', '', ''),
(19, 2, 1, 'New Tab ', '', ''),
(4, 3, 0, 'New', '', '<table border="0" cellspacing="0" cellpadding="0" width="100%" style="color:#666666;font-family:Verdana, Arial, 宋体;font-size:12px;background-color:#FFFFFF;" class="ke-zeroborder">\n	<tbody>\n		<tr>\n			<td valign="top" style="font-family:Verdana, Arial, 宋体;">\n				<table border="0" cellspacing="5" cellpadding="0" class="ke-zeroborder" style="width:100%;">\n					<tbody>\n						<tr>\n							<td align="left" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<table border="0" cellspacing="0" cellpadding="0" width="100%" class="ke-zeroborder">\n									<tbody>\n										<tr>\n											<td height="25" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n												<strong><span class="about_title" style="color:#585656;line-height:2;">我们的背景</span><span style="line-height:2;">&nbsp;Our History</span></strong> \n											</td>\n										</tr>\n										<tr>\n											<td class="about_bom" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n												<span style="line-height:2;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 深圳市群合科技开发有限公司，成立于2003年，是一家专业服务于企业信息化建设的提供商（ASP），是网络信息技术产业的高新科技企业。群合网络</span><a href="http://www.qunhe.com/"><span style="line-height:2;">www.qunhe.com</span></a><span style="line-height:2;">是深圳市群合科技开发有限公司旗下网站，主要提供网页设计、网站建设、网站推广、程序开发、域名服务、主机服务、网络广告、品牌形象策划等全方位的一体化服务，为企业打造专业的网络形象，使企业可以在成本、效率、稳定的前提下应用网络服务，展现自我风格和特色，创造更多的价值和效益。</span> \n											</td>\n										</tr>\n									</tbody>\n								</table>\n							</td>\n						</tr>\n						<tr>\n							<td height="25" align="left" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<strong><span class="about_title" style="color:#585656;line-height:2;">我们的理念</span><span style="line-height:2;">&nbsp;Our Philosophy</span></strong> \n							</td>\n						</tr>\n						<tr>\n							<td class="about_bom" align="left" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<span style="line-height:2;">&nbsp;&nbsp;&nbsp;&nbsp;</span><span style="line-height:2;">&nbsp;&nbsp;“在线服务，服务在线”是群合网络一贯执行的以用户为中心的服务理念，真正、真心地站在用户的角度，尽企业之所能，以人性化的服务和优质的成果满足用户个性化的需求。</span> \n							</td>\n						</tr>\n						<tr>\n							<td height="25" align="left" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<strong><span class="about_title" style="color:#585656;line-height:2;">我们的团队</span><span style="line-height:2;">&nbsp;Our Team</span></strong> \n							</td>\n						</tr>\n						<tr>\n							<td class="about_bom" align="left" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<span style="line-height:2;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 我们拥有一支团结协作、素质过硬、技术一流、有丰富经验和独具创意的专业网站设计开发人员和网络营销策划专家，企业推行以人为本的管理方针，不断树立企业自身的文化。企业在不断发展的同时，始终关注员工的成长，通过"结构化选人、职业化用人、个性化育人、情感化留人"构建起综合的人力资源体系，努力培养员工的归属感和勇于承担社会责任的良好品质。</span> \n							</td>\n						</tr>\n						<tr>\n							<td height="25" align="left" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<strong><span class="about_title" style="color:#585656;line-height:2;">我们的目标</span><span style="line-height:2;">&nbsp;Our Goal</span></strong> \n							</td>\n						</tr>\n						<tr>\n							<td class="about_bom" align="left" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<span style="line-height:2;">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 本着让客户满意的目标，充分利用互联网以快速、不受时空限制、全方位的服务，把最好的技术通过最有效、最简单的方式提供给客户，帮助企业获取市场信息、把握商机、真正体现网络互动的优势；通过数字化网络的交流，建立和发展你我共享的信息平台。群合网络将通过不懈努力成为客户在信息化领域值得信任、有价值的长期合作伙伴。</span> \n							</td>\n						</tr>\n					</tbody>\n				</table>\n			</td>\n			<td valign="top" width="333" align="right" style="font-family:Verdana, Arial, 宋体;">\n				<img src="http://web.qunhe.com/images/about_rightpc.jpg" width="300" height="417" /> \n			</td>\n		</tr>\n	</tbody>\n</table>\n<table border="0" cellspacing="0" cellpadding="0" width="100%" style="color:#666666;font-family:Verdana, Arial, 宋体;font-size:12px;background-color:#FFFFFF;" class="ke-zeroborder">\n	<tbody>\n		<tr>\n			<td style="font-family:Verdana, Arial, 宋体;">\n				<span style="line-height:2;">&nbsp;</span> \n			</td>\n		</tr>\n		<tr>\n			<td style="font-family:Verdana, Arial, 宋体;">\n				<table border="0" cellspacing="0" cellpadding="0" width="100%" class="ke-zeroborder">\n					<tbody>\n						<tr>\n							<td width="55" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<img src="http://web.qunhe.com/images/about_1.jpg" width="48" height="48" /> \n							</td>\n							<td valign="top" width="410" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<span style="line-height:2;">10年丰富的网站建设经验</span><br />\n<span style="line-height:2;"> 业精于专，设计和技术实力雄厚，多年经验铸造品质保证；</span> \n							</td>\n							<td width="55" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<img src="http://web.qunhe.com/images/about_2.jpg" width="48" height="48" /> \n							</td>\n							<td valign="top" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<span style="line-height:2;">10年丰富的网站建设经验</span><br />\n<span style="line-height:2;"> 业精于专，设计和技术实力雄厚，多年经验铸造品质保证；</span> \n							</td>\n						</tr>\n						<tr>\n							<td style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<img src="http://web.qunhe.com/images/about_3.jpg" width="48" height="48" /> \n							</td>\n							<td valign="top" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<span style="line-height:2;">10年丰富的网站建设经验</span><br />\n<span style="line-height:2;"> 业精于专，设计和技术实力雄厚，多年经验铸造品质保证；</span> \n							</td>\n							<td style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<img src="http://web.qunhe.com/images/about_4.jpg" width="48" height="48" /> \n							</td>\n							<td valign="top" style="font-family:Verdana, Arial, 宋体;color:#666666;">\n								<span style="line-height:2;">10年丰富的网站建设经验</span><br />\n<span style="line-height:2;"> 业精于专，设计和技术实力雄厚，多年经验铸造品质保证；</span> \n							</td>\n						</tr>\n					</tbody>\n				</table>\n			</td>\n		</tr>\n	</tbody>\n</table>'),
(20, 11, 0, 'New', '', '<strong>站长之家（CHINAZ.com）12月2日报道</strong>：据外媒报道，谷歌日前已经更新了其十二月份的搜索算法，其中最显著的一个变化是，谷歌表示它将把停放的域名排除在搜索索引之外，而一个新的算法将被用于检测停放的域名。<br />\n<br />\n在谷歌官方博客中，谷歌搜索项目主管斯科特·霍夫曼（Scott Huffman）表示谷歌已经开始每月针对其搜索算法和布局推出一系列更新，并且计划继续披露这些变化的具体细节，使搜索更加透明化。霍夫曼称，自11月14日起，谷歌就已经制定了一个关于“停放的域名”的分类，这是一个用于自动检测停放的域名的新算法，由于停放的域名指向的是一些鲜有用处且往往被广告填满的站点，很少对用户提供有价值的内容，所以在大多数情况下，谷歌宁愿不向用户展示出来。<br />\n<br />\n过去常常有很多停放的页面被索引，这给域名所有者在type-in流量和旧链外传递了很多额外的流量，谷歌近几年显然意识到这一点，并采取了相应的措施。<br />\n<br />\n除此之外，谷歌也正在寻找克隆的网站，以更好地辨别原始素材。有关图片和博客搜索，谷歌此次也调整了算法来提高展示内容的新鲜度。谷歌还调整了它在网页搜索上的格式，使一台主机上显示较少的结果，自动完成结果也得到了改善。（糖糖）<br />'),
(7, 4, 0, 'New', '', '<div class="web_stepbox fl" style="margin:35px 0px 0px;padding:0px;border:1px solid #EEEEEE;font-family:宋体;background-color:#F2F2F2;">\n	<div class="title_a" style="margin:0px;padding:0px 10px;background-color:#F9F9F9;font-size:16px;font-family:微软雅黑;color:#424242;">\n		业务流程<em>Business processes</em> \n	</div>\n	<div class="web_step_webzi fl" style="margin:30px 0px 0px;padding:0px;color:#333333;font-family:微软雅黑;">\n		<ul>\n			<li class="one" style="text-align:center;">\n				电话沟通、确认意向\n			</li>\n			<li class="one" style="text-align:center;">\n				签订协议、设计首页\n			</li>\n			<li class="two" style="text-align:center;">\n				制作页面与后台\n			</li>\n			<li class="two" style="text-align:center;">\n				验收付款\n			</li>\n			<li class="two" style="text-align:center;">\n				后期维护\n			</li>\n		</ul>\n	</div>\n	<div class="web_step_jsbox fl" style="margin:-8px 0px 0px;padding:0px;">\n	</div>\n</div>\n<div class="web_taocan fl" style="margin:20px 0px 0px;padding:0px 0px 5px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="web_tao_picbox fl" style="margin:0px;padding:0px;">\n		<p class="name" style="text-align:center;color:#86C512;font-size:18px;font-family:黑体;">\n			创业基础型\n		</p>\n		<p style="text-align:center;">\n			<img src="http://www.mcpinpai.com/images/tao1.jpg" width="112" height="120" alt="创业基础型" /> \n		</p>\n		<p class="price" style="text-align:center;color:#CA0101;font-weight:700;">\n			优惠价：1680元\n		</p>\n	</div>\n	<div class="web_tao_infobox fr" style="margin:0px;padding:0px;color:#666666;">\n		<p>\n			<span class="name fl" style="font-weight:700;">适用客户：</span><span class="desc fr">适合中、小型企业建立低成本的小型宣传网站</span><span class="name fl" style="font-weight:700;">设计理念：</span><span class="desc fr">设计合理、内容简洁，整个版面让人耳目 一新</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站功能：</span><span class="desc fr">公司介绍管理系统、产品展示管理系统、留言 板管理系统、联系我们管理系统</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站维护：</span><span class="desc fr">1年免费维护（包括内容的删减及更新，不包 括结构变更，一年不超过10次）</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">工作周期：</span><span class="desc fr">7--10个工作日</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站推广：</span><span class="desc fr">免费在国内外搜索引擎上注册，推广您的网站 。免费提供网站源代码优化服务</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">增值服务：</span><span class="desc fr">第一年免费赠送国际域名/国内域名一个，服务器空间150M，网站数据备份空间150M，企业邮箱100M，10个用户</span> \n		</p>\n		<p>\n			<span class="fr more_a"><a href="http://www.mcpinpai.com/html/design/view-1.html">[更多详情]</a></span> \n		</p>\n	</div>\n</div>\n<div class="web_taocan fl" style="margin:20px 0px 0px;padding:0px 0px 5px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="web_tao_picbox fl" style="margin:0px;padding:0px;">\n		<p class="name" style="text-align:center;color:#86C512;font-size:18px;font-family:黑体;">\n			标准设计型\n		</p>\n		<p style="text-align:center;">\n			<img src="http://www.mcpinpai.com/uploads/2012122316391891261.jpg" width="112" height="120" alt="标准设计型" /> \n		</p>\n		<p class="price" style="text-align:center;color:#CA0101;font-weight:700;">\n			优惠价：3500元\n		</p>\n	</div>\n	<div class="web_tao_infobox fr" style="margin:0px;padding:0px;color:#666666;">\n		<p>\n			<span class="name fl" style="font-weight:700;">适用客户：</span><span class="desc fr">适合中、小型企业建立企业行业标准网站</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">设计理念：</span><span class="desc fr">设计精美、大气，首页动画展示，结合行业动态，体现网站在行业的形象，带有数据库，可自动生成无数个内页。</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站功能：</span><span class="desc fr">公司介绍管理系统、产品展示管理系统、留言板管理系统、信息管理系统、联系我们管理系统、流量统计分析系统、查询系统…</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站维护：</span><span class="desc fr">1年免费维护（包括内容的删减及更新，不包括结构变更，一年不超过10次）</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">工作周期：</span><span class="desc fr">15--20个工作日</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站推广：</span><span class="desc fr">免费在国内外搜索引擎上注册，推广您的网站。免费提供网站源代码优化服务</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">增值服务：</span><span class="desc fr">第一年免费赠送国际域名/国内域名一个，服务器空间200M；网站数据备份空间200M，企业邮箱200M，20个用户</span> \n		</p>\n		<p>\n			<span class="fr more_a"><a href="http://www.mcpinpai.com/html/design/view-2.html">[更多详情]</a></span> \n		</p>\n	</div>\n</div>\n<div class="web_taocan fl" style="margin:20px 0px 0px;padding:0px 0px 5px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="web_tao_picbox fl" style="margin:0px;padding:0px;">\n		<p class="name" style="text-align:center;color:#86C512;font-size:18px;font-family:黑体;">\n			商务营销型\n		</p>\n		<p style="text-align:center;">\n			<img src="http://www.mcpinpai.com/images/tao3.jpg" width="112" height="120" alt="商务营销型" /> \n		</p>\n		<p class="price" style="text-align:center;color:#CA0101;font-weight:700;">\n			优惠价：4800元\n		</p>\n	</div>\n	<div class="web_tao_infobox fr" style="margin:0px;padding:0px;color:#666666;">\n		<p>\n			<span class="name fl" style="font-weight:700;">适用客户：</span><span class="desc fr">适合中、小型企业建立低成本的小型宣传网站</span><span class="name fl" style="font-weight:700;">设计理念：</span><span class="desc fr">突出企业在行业的地位，展现企业的整体形象。整体形象设计包括导航栏设计、标准字、Logo、标准色彩、 首页设计包括版面、色彩、图像、动态效果、图标等风格设计</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站功能：</span><span class="desc fr">公司介绍管理系统、产品展示管理系统、留言板管理系统、信息管理系统、联系我们管理系统、流量统计分析系统、上传下载系统、人才招聘系统…</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站维护：</span><span class="desc fr">1年免费维护（包括内容的删减及更新，不包括结构变更，一年不超过12次）</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">工作周期：</span><span class="desc fr">20--25个工作日</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站推广：</span><span class="desc fr">免费在国内外搜索引擎上注册，推广您的网站。免费提供网站源代码优化服务</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">增值服务：</span><span class="desc fr">第一年免费赠送国际域名/国内域名一个，服务器空间500M，网站数据备份空间500M，企业邮箱400M，40个用户</span> \n		</p>\n		<p>\n			<span class="fr more_a"><a href="http://www.mcpinpai.com/html/design/view-3.html">[更多详情]</a></span> \n		</p>\n	</div>\n</div>\n<div class="web_taocan fl" style="margin:20px 0px 0px;padding:0px 0px 5px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="web_tao_picbox fl" style="margin:0px;padding:0px;">\n		<p class="name" style="text-align:center;color:#86C512;font-size:18px;font-family:黑体;">\n			品牌营销型\n		</p>\n		<p style="text-align:center;">\n			<img src="http://www.mcpinpai.com/images/tao4.jpg" width="112" height="120" alt="品牌营销型" /> \n		</p>\n		<p class="price" style="text-align:center;color:#CA0101;font-weight:700;">\n			优惠价：面议\n		</p>\n	</div>\n	<div class="web_tao_infobox fr" style="margin:0px;padding:0px;color:#666666;">\n		<p>\n			<span class="name fl" style="font-weight:700;">适用客户：</span><span class="desc fr">适合大、中、小型企业建立企业品牌形象宣传网站</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">设计理念：</span><span class="desc fr">整体形象设计包括导航栏设计、标准字、Logo、标准色彩、 首页设计包括版面、色彩、图像、动态效果、图标等风格设计，也包括banner、菜单、标题、版权等模块设计。</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站功能：</span><span class="desc fr">公司介绍管理系统、产品展示管理系统、留言板管理系统、信息管理系统、联系我们管理系统、流量统计分析系统、上传下载系统、人才招聘系统…</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站维护：</span><span class="desc fr">1年免费维护（包括内容的删减及更新，不包括结构变更，一年不超过15次</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">工作周期：</span><span class="desc fr">20--25个工作日</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站推广：</span><span class="desc fr">免费在国内外搜索引擎上注册，推广您的网站。免费提供网站源代码优化服务</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">增值服务：</span><span class="desc fr">第一年免费赠送国际域名/国内域名一个，服务器空间1G，网站数据备份空间1G，企业邮箱600M，60个用户</span> \n		</p>\n		<p>\n			<span class="fr more_a"><a href="http://www.mcpinpai.com/html/design/view-4.html">[更多详情]</a></span> \n		</p>\n	</div>\n</div>\n<div class="web_taocan fl" style="margin:20px 0px 0px;padding:0px 0px 5px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="web_tao_picbox fl" style="margin:0px;padding:0px;">\n		<p class="name" style="text-align:center;color:#86C512;font-size:18px;font-family:黑体;">\n			商城网店型\n		</p>\n		<p style="text-align:center;">\n			<img src="http://www.mcpinpai.com/images/tao5.jpg" width="112" height="120" alt="商城网店型" /> \n		</p>\n		<p class="price" style="text-align:center;color:#CA0101;font-weight:700;">\n			优惠价:面议\n		</p>\n	</div>\n	<div class="web_tao_infobox fr" style="margin:0px;padding:0px;color:#666666;">\n		<p>\n			<span class="name fl" style="font-weight:700;">适用客户：</span><span class="desc fr">适合大、中、小型企业建立电子商务宣传网站</span><span class="name fl" style="font-weight:700;">设计理念：</span><span class="desc fr">模块布局宗旨在于方便全球访问者浏览，页面布局力求风格统一、内容丰富，清晰明了，网站程序代码整齐，提高浏览速度。给人以较为直观的感受，以及更为感性的认识…</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站功能：</span><span class="desc fr">公司介绍管理系统、产品展示管理系统、在线订购系统、订单系统、积分管理系统、留言板管理系统、信息管理系统、联系我们管理系统、流量统计分析系统、上传下载系统…</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站维护：</span><span class="desc fr">1年免费维护（包括内容的删减及更新，不包括结构变更，一年不超过12次）</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">工作周期：</span><span class="desc fr">20--25个工作日</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">网站推广：</span><span class="desc fr">免费在国内外搜索引擎上注册，推广您的网站。免费提供网站源代码优化服务</span> \n		</p>\n		<p>\n			<span class="name fl" style="font-weight:700;">增值服务：</span><span class="desc fr">第一年免费赠送国际域名/国内域名一个，服务器空间1G，网站数据备份空间1G，企业邮箱600M，60个用户</span> \n		</p>\n		<p>\n			<span class="fr more_a"><a href="http://www.mcpinpai.com/html/design/view-5.html">[更多详情]</a></span> \n		</p>\n	</div>\n</div>'),
(9, 5, 0, 'New', '', '<div class="contact_lxone fl" style="margin:0px;padding:0px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="title_a fl" style="margin:0px;padding:0px;font-size:18px;font-family:微软雅黑;color:#86C512;">\n		<span><img src="http://www.mcpinpai.com/images/de_lx1.jpg" width="57" height="47" alt="" style="width:57px;height:47px;" /></span><span>公司地址</span>\n	</div>\n	<p style="color:#666666;">\n		地址：深圳市龙华镇龙胜西路佳利科技大厦2楼210\n	</p>\n	<p style="color:#666666;">\n		邮编：518052\n	</p>\n	<p style="color:#666666;">\n		网址： www.mcpinpai.com\n	</p>\n</div>\n<div class="contact_lxtwo fl" style="margin:0px;padding:0px 0px 0px 20px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="title_a fl" style="margin:0px;padding:0px;font-size:18px;font-family:微软雅黑;color:#86C512;">\n		<span><img src="http://www.mcpinpai.com/images/de_lx2.jpg" width="57" height="47" alt="" style="width:57px;height:47px;" /></span><span>联系方式</span>\n	</div>\n	<p style="color:#666666;">\n		电话：0755-23274906\n	</p>\n	<p style="color:#666666;">\n		传真：0755-23274906\n	</p>\n	<p style="color:#666666;">\n		手机：13760418741 李先生 (客户总监)\n	</p>\n	<p style="color:#666666;">\n		QQ：179920616\n	</p>\n</div>\n<div class="contact_lxtwo fl" style="margin:0px;padding:0px 0px 0px 20px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="title_a fl" style="margin:0px;padding:0px;font-size:18px;font-family:微软雅黑;color:#86C512;">\n		<span><img src="http://www.mcpinpai.com/images/de_lx3.jpg" width="57" height="47" alt="" style="width:57px;height:47px;" /></span><span>公司邮箱</span>\n	</div>\n	<p style="color:#666666;">\n		sales@mcpinpai.com\n	</p>\n	<p style="color:#666666;">\n		非工作日时间请给我们留言\n	</p>\n	<p style="color:#666666;">\n		我们将尽快给您回复\n	</p>\n</div>'),
(10, 6, 0, 'New', '', '<h2 style="font-size:36px;color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;background-color:#FFFFFF;">\n	Nulla dapibus lectus ut nulla\n</h2>\n<span style="color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:20px;background-color:#FFFFFF;">May 24th in&nbsp;</span><a href="http://www.cssmoban.com/" target="_parent">Web Template</a><span style="color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:20px;background-color:#FFFFFF;">&nbsp;by&nbsp;</span><a href="http://www.cssmoban.com/" target="_parent">网页模板</a><span style="color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:20px;background-color:#FFFFFF;"></span> \n<div class="post_content" style="margin:0px;padding:0px;color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;background-color:#FFFFFF;">\n	<div class="left" style="margin:0px;padding:0px;">\n		<img src="http://www.kona.com/assets/themes/business/images/templatemo_image_01.jpg" alt="image" /> \n	</div>\n	<div class="right" style="margin:0px;padding:0px;">\n		<p>\n			Curabitur mollis mi non elit mollis sit amet sodales lectus tempor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent eu erat neque. Nullam consequat ipsum at tellus ultrices bibendum.\n		</p>\n	</div>\n</div>'),
(11, 7, 0, 'New', '', ''),
(12, 8, 0, 'New', '', ''),
(13, 6, 0, 'New Tab ', '', '<h2 style="font-size:36px;color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;background-color:#FFFFFF;">\n	Lorem ipsum dolor sit amet\n</h2>\n<span style="color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:20px;background-color:#FFFFFF;">May 24th in&nbsp;</span><a href="http://www.cssmoban.com/" target="_parent">Web Template</a><span style="color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:20px;background-color:#FFFFFF;">&nbsp;by&nbsp;</span><a href="http://www.cssmoban.com/" target="_parent">网页模板</a><span style="color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;line-height:20px;background-color:#FFFFFF;"></span> \n<div class="post_content" style="margin:0px;padding:0px;color:#4A4A4A;font-family:Arial, Helvetica, sans-serif;font-size:14px;background-color:#FFFFFF;">\n	<div class="left" style="margin:0px;padding:0px;">\n		<img src="http://www.kona.com/assets/themes/business/images/templatemo_image_02.jpg" alt="image" /> \n	</div>\n	<div class="right" style="margin:0px;padding:0px;">\n		<p>\n			Nullam consequat ipsum at tellus ultrices bibendum. Donec elit orci, semper malesuada lacinia non, interdum nec lorem. Donec sagittis venenatis magna, vitae scelerisque nibh elementum iaculis. Sed ipsum urna, rhoncus at elementum eu, bibendum at nisl. Maecenas libero massa, lobortis at aliquam at, convallis bibendum odio. Aliquam molestie felis non ipsum scelerisque.\n		</p>\n<a href="http://www.kona.com/list/news#">Continue reading...</a>&nbsp;|&nbsp;<a href="http://www.kona.com/list/subpage.html">Comments (68)</a> \n	</div>\n</div>'),
(14, 6, 0, 'New Tab ', '', '<img src="/assets/uploads/attached/image/20130112/20130112172346_72089.png" alt="" /><img src="/assets/admin/kindeditor/attached/image/20130112/20130112171816_26372.jpg" alt="" />'),
(15, 9, 0, 'New', '', '<p style="color:#898989;font-family:微软雅黑;text-indent:24px;background-color:#F2F2F2;">\n	中易软件广告联盟。 客户在这上面发布广告类型，站长在这获取广告再放在自己网站上，是他们的平台。\n</p>\n<p style="color:#898989;font-family:微软雅黑;text-indent:24px;background-color:#F2F2F2;">\n	<img alt="" width="900" height="750" src="http://www.mcpinpai.com/uploads/20121221191059439020.jpg" /> \n</p>\n<p style="color:#898989;font-family:微软雅黑;text-indent:24px;background-color:#F2F2F2;">\n	<img alt="" width="900" height="750" src="http://www.mcpinpai.com/uploads/20121221191124629152.jpg" /> \n</p>'),
(18, 10, 0, 'New', '', '<div class="web_stepbox fl" style="margin:35px 0px 0px;padding:0px;border:1px solid #EEEEEE;font-family:宋体;background-color:#F2F2F2;">\n	<div class="title_a" style="margin:0px;padding:0px 10px;background-color:#F9F9F9;font-size:16px;font-family:微软雅黑;color:#424242;">\n		业务流程<em>Business processes</em> \n	</div>\n	<div class="web_step_webzi fl" style="margin:30px 0px 0px;padding:0px;color:#333333;font-family:微软雅黑;">\n		<ul>\n			<li class="one" style="text-align:center;">\n				电话沟通、确认意向\n			</li>\n			<li class="one" style="text-align:center;">\n				签订协议、设计首页\n			</li>\n			<li class="two" style="text-align:center;">\n				制作页面与后台\n			</li>\n			<li class="two" style="text-align:center;">\n				验收付款\n			</li>\n			<li class="two" style="text-align:center;">\n				后期维护\n			</li>\n		</ul>\n	</div>\n	<div class="web_step_jsbox fl" style="margin:-8px 0px 0px;padding:0px;">\n	</div>\n</div>\n<div class="web_taocan fl" style="margin:20px 0px 0px;padding:0px 0px 5px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="web_tao_picbox fl" style="margin:0px;padding:0px;">\n		<p style="text-align:center;">\n			<img src="http://www.mcpinpai.com/images/tao1.jpg" width="112" height="120" alt="" /> \n		</p>\n		<p class="name" style="text-align:center;color:#86C512;font-size:18px;font-family:黑体;">\n			商城网店型\n		</p>\n	</div>\n	<div class="web_tao_infobox fr" style="margin:0px;padding:0px;color:#666666;">\n		<p>\n			开辟网上商机中型企业设计，专业的企业上网营销方案。为商城量身定制设计精美页面，可实现网上交易，网上支付功能，专业的网站营销型网站。网上商城系统以构建电子商务网站为目标，由前台购物、后台管理、在线支付、会员管理、实时咨询等模块组成。各大模块完美结合，将能实现最为完善和强大的功能...\n		</p>\n		<p>\n			<span class="goumai_price" style="color:#CA0101;font-weight:700;line-height:30px;">优惠价:面议</span><span><a href="http://info/contact.html"><img src="http://www.mcpinpai.com/images/gm.gif" width="75" height="27" alt="" /></a></span> \n		</p>\n	</div>\n</div>\n<div class="web_more_listbox fl" style="margin:20px 0px 0px;padding:0px;font-family:宋体;background-color:#F2F2F2;">\n	<div class="title_e fl" style="margin:0px;padding:0px;color:#00A0E9;font-weight:700;">\n		普及型套餐详细介绍：\n	</div>\n	<div class="title_f fl" style="margin:5px 0px;padding:0px 0px 0px 12px;color:#434343;font-weight:700;">\n		主机域名参数：\n	</div>\n	<p style="color:#898989;">\n		域名：可选国际或国内顶级英文域名一个， 例如：<a href="http://www.mcpinpai.com/">http://www.mcpinpai.com</a> \n	</p>\n	<p style="color:#898989;">\n		空间：1000MB西部数码双线企业型虚拟主机空间，月流量40GB(支持ASP、PHP、JSP、ASP.NET、ACCESS、MSSQL、MYSQL 数据库)\n	</p>\n	<p style="color:#898989;">\n		邮箱：600MB可自主管理及分配的WEB企业邮局，支持POP、SMTP功能。可开通60个独立邮箱帐户\n	</p>\n	<p style="color:#898989;">\n		网站开发语言：PHP5&nbsp;&nbsp; &nbsp;数据库：Microsoft MySQL Server （100MB）\n	</p>\n	<div class="title_f fl" style="margin:5px 0px;padding:0px 0px 0px 12px;color:#434343;font-weight:700;">\n		网站功能栏目：\n	</div>\n	<p style="color:#898989;">\n		网站首页：首页设计突出公司形象、颜色、最新产品等功能，可选首页嵌入FLASH动画效果，进入中英文版本等功能 。\n	</p>\n	<p style="color:#898989;">\n		公司介绍：公司/企业的全面介绍，企业文化、服务理念、规模介绍、厂房图片、资质认证、实力等方面的介绍。\n	</p>\n	<p style="color:#898989;">\n		产品展示：以图文形式介绍公司的主营产品、最新产品等信息，主营服务，服务范围（可选二级产品分类）。\n	</p>\n	<p style="color:#898989;">\n		产品搜索：根据客户自身要求输入关键字在线搜索商品，更方便客户查找商品。\n	</p>\n	<p style="color:#898989;">\n		会员系统：会员可分等级(区分普通用户、VIP用户、代理商、加盟商)，更好保护产品设计及价格分级销售。\n	</p>\n	<p style="color:#898989;">\n		在线订单：在线订购产品、多选型购物车，可在线修改、删除等管理购物车内商品。\n	</p>\n	<p style="color:#898989;">\n		在线支付：可接入支付宝、网银、快钱等在线支付方式。\n	</p>\n	<p style="color:#898989;">\n		商品搜索：根据客户自身要求输入关键字在线搜索商品，更方便客户查找商品。\n	</p>\n	<p style="color:#898989;">\n		商品评论：客户可对商品在线提交意见、评论。\n	</p>\n	<p style="color:#898989;">\n		新闻动态：发布公司最新信息动态、促销活动、招聘信息、行业新闻等内容。\n	</p>\n	<p style="color:#898989;">\n		人才招聘：通过自己公司网站发布公司招聘信息，提高形像，降低招聘成本，更有效地招聘到人才。\n	</p>\n	<p style="color:#898989;">\n		客户留言：方便客户通地互联网直接与客户沟通，接收订单，意见反馈等信息。大大降低销售成本。\n	</p>\n	<p style="color:#898989;">\n		联系方式：让客户清楚了解公司相关联系方式，包括电话、地址、联系人，手机、银行帐号等。\n	</p>\n	<p style="color:#898989;">\n		论坛博客：方便客户通地互联网直接商家间的沟通，接收订单，信息反馈等信息。大大提交平台的人气。\n	</p>\n	<p style="color:#898989;">\n		WAP建站：开通企业WAP网站，支持手机用户访问，内容包括网站首页、公司介绍、产品展示、新闻动态、人才招聘、客户留言、联系方式等WAP栏目。\n	</p>\n	<div class="title_f fl" style="margin:5px 0px;padding:0px 0px 0px 12px;color:#434343;font-weight:700;">\n		应用程序系统：\n	</div>\n	<p style="color:#898989;">\n		客户留言系统：记录客户相关联系方式：公司名称、联系人、电话、手机、反馈意见、订单等信息。网站管理员可查 看所有客户留言记录。\n	</p>\n	<p style="color:#898989;">\n		产品展示系统：可在线添加分类、产品、在线上传产品图片、自主添加、修改以及删除。提高信息发布时效，无需专 门的技术人员，减少相关制作人员的工作量，真正实现轻松、快捷、高效。\n	</p>\n	<p style="color:#898989;">\n		会员管理系统：可查看、修改网站所有会员信息，会员等级、权限开通，产品/消息/报价的分级别加密。\n	</p>\n	<p style="color:#898989;">\n		订单管理系统：查看管理订单详细内容，以及订单状态修改(发货/待支付)等处理。\n	</p>\n	<p style="color:#898989;">\n		商品评论系统：查看、修改客户的评论，并可及时回复客户评论。\n	</p>\n	<p style="color:#898989;">\n		新闻发布系统：可在线添加新闻、自主修改以及删除。提高信息发布时效，无需专门的技术人员，减少相关制作人员 的工作量，真正实现轻松、快捷、高效。\n	</p>\n	<p style="color:#898989;">\n		人才招聘系统：可在线发布招聘信息、自主添加、修改以及删除。提高信息招聘效率，无需专门的技术人员，减少相 关制作人员的工作量，真正实现轻松、快捷、高效。\n	</p>\n	<p style="color:#898989;">\n		网站计数器系统：记录网站每天、每月、每年的的客户浏览数量、同时在线人数等信息。\n	</p>\n	<div class="title_f fl" style="margin:5px 0px;padding:0px 0px 0px 12px;color:#434343;font-weight:700;">\n		免费增值服务：\n	</div>\n	<p style="color:#898989;">\n		站点页面优化，搜索关键字优化，标准网站营销服务。\n	</p>\n	<p style="color:#898989;">\n		供建站咨询报告，域名、网站名称设计。\n	</p>\n	<p style="color:#898989;">\n		网站内容规划，最佳预算建议，最佳方案建议。\n	</p>\n	<p style="color:#898989;">\n		域名注册/续费/解析/管理，网站虚拟主机空间开通/维护/管理。\n	</p>\n	<p style="color:#898989;">\n		企业邮箱帐户开通/设置/管理，网站设计/制作/测试/发布全过程。\n	</p>\n	<p style="color:#898989;">\n		访问量，独立IP，浏览量，浏览深度分析与技术支持。\n	</p>\n	<p style="color:#898989;">\n		免费登陆国内著名搜索引擎（雅虎中国、Google、百度、中搜、一搜、搜狐）。\n	</p>\n	<p style="color:#898989;">\n		提交ALEXA服务。\n	</p>\n	<p style="color:#898989;">\n		免费ICP网站备案。\n	</p>\n	<div class="title_f fl" style="margin:5px 0px;padding:0px 0px 0px 12px;color:#434343;font-weight:700;">\n		售后服务：\n	</div>\n	<p style="color:#898989;">\n		一年内提供免费内容维护<strong>15</strong>页次（页面内容、文字修改，非需触动页面模板的情况下）\n	</p>\n	<p style="color:#898989;">\n		网站运行监控、文件定期备份，保证客户资料不会丢失。\n	</p>\n	<p style="color:#898989;">\n		企业网站应用和营销建议报告，提供年度网站流量报告。\n	</p>\n	<div class="title_f fl" style="margin:5px 0px;padding:0px 0px 0px 12px;color:#434343;font-weight:700;">\n		备注：\n	</div>\n	<p style="color:#898989;">\n		支持多个语言版本开发、制作，如英文版、简体中文、繁体中文等。\n	</p>\n	<p style="color:#898989;">\n		老客户网站改版和升级可享受9折优惠，老客户推荐的新客户有享受9折优惠。\n	</p>\n	<p style="color:#898989;">\n		建站方案价格报价不含税，开发票外加3%个点,可开增值税专用发票。\n	</p>\n</div>'),
(21, 12, 0, 'New', '', ''),
(22, 13, 0, 'New', '', ''),
(23, 14, 0, 'New', '', ''),
(27, 18, 0, 'New', '', ''),
(26, 17, 0, 'New', '', ''),
(28, 19, 0, 'New', '', ''),
(30, 21, 0, 'New', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `ko_article_language`
--

CREATE TABLE IF NOT EXISTS `ko_article_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `article_id` int(11) NOT NULL COMMENT '文章ID',
  `language_id` smallint(6) NOT NULL COMMENT '语系ID',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `seo_title` varchar(100) NOT NULL COMMENT 'SEO标题',
  `seo_description` varchar(250) NOT NULL COMMENT '简述',
  `seo_keywords` varchar(200) NOT NULL COMMENT '关键词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `ko_article_language`
--

INSERT INTO `ko_article_language` (`id`, `article_id`, `language_id`, `title`, `seo_title`, `seo_description`, `seo_keywords`) VALUES
(1, 2, 1, '11', '', 'ssss', 'bbbb'),
(2, 2, 2, '11', '', 'ssss', '22222');

-- --------------------------------------------------------

--
-- 表的结构 `ko_catalog`
--

CREATE TABLE IF NOT EXISTS `ko_catalog` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `parent_id` smallint(6) NOT NULL COMMENT '父ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `thumb` varchar(200) NOT NULL DEFAULT '' COMMENT '缩略图',
  `image` varchar(200) NOT NULL COMMENT '图片',
  `link` varchar(250) NOT NULL COMMENT '链接',
  `target` varchar(20) NOT NULL COMMENT '打开方式',
  `desc` text NOT NULL COMMENT '描述',
  `template` varchar(100) NOT NULL COMMENT '模板',
  `sort_order` smallint(6) NOT NULL DEFAULT '50' COMMENT '排序',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  `rewrite_url` varchar(100) NOT NULL COMMENT '自定义链接',
  `seo_title` varchar(100) NOT NULL COMMENT '标题',
  `seo_keywords` varchar(100) NOT NULL COMMENT '关键字',
  `seo_description` varchar(200) NOT NULL COMMENT '简述',
  `article_columns` varchar(500) NOT NULL DEFAULT '' COMMENT '文章欄位',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=27 ;

--
-- 转存表中的数据 `ko_catalog`
--

INSERT INTO `ko_catalog` (`id`, `parent_id`, `title`, `thumb`, `image`, `link`, `target`, `desc`, `template`, `sort_order`, `status`, `rewrite_url`, `seo_title`, `seo_keywords`, `seo_description`, `article_columns`) VALUES
(1, 0, 'header', '', '1', '/', '_self', '', '', 0, 1, '', '1', '1', '1', ''),
(2, 1, 'About Us', '', '', '', '_self', '', 'about_us', 0, 1, 'about', '', '', '', ''),
(3, 1, '婚宴', '', '', '#', '_self', '', '', 0, 1, '', '', '', '', ''),
(4, 1, 'Case', '', '', '', '_self', '', '', 0, 1, 'case', '', '', '', ''),
(5, 1, 'News', '', '', '', '_self', '', '', 0, 1, 'news', '', '', '', ''),
(6, 1, 'Contact Us', '', '1', '', '_self', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.', 'contact', 0, 1, 'contact_us', '1', '1', '1', ''),
(13, 1, 'test', '', '', '', '_self', 'B Mission\n\nDB is a Project of the Apache Software Foundation, charged with the creation and maintenance of commercial-quality, open-source, database solutions based on software licensed to the Foundation, for distribution at no charge to the public.\n\nApache Software Foundation\n\nThe Apache Software Foundation provides support for the Apache community of open-source software projects. The Apache projects are characterized by a collaborative, consensus based development process, an open and pragmatic software license, and a desire to create high quality software that leads the way in its field.', '', 0, 1, '', '', '', '', ''),
(9, 1, '首頁', '', '', '/', '_self', '', 'index', -1, 1, '', '', '', '', ''),
(10, 3, '九龍半山', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(11, 3, '九龍東', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(12, 3, '大舞臺', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(14, 9, '集團獎項', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(15, 9, '新聞稿', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(16, 9, '傳媒查詢', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(17, 9, '報道', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(18, 9, '社會責任', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(19, 9, '合作伙伴', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(20, 3, '銀灘', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(21, 20, '簡介', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(22, 20, '場地實景', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(23, 20, '實景短片', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(24, 10, '簡介', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(25, 10, '場地實景', '', '', '', '_self', '', '', 0, 1, '', '', '', '', ''),
(26, 10, '實景短片', '', '', '', '_self', '', '', 0, 1, '', '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `ko_catalog_language`
--

CREATE TABLE IF NOT EXISTS `ko_catalog_language` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `catalog_id` smallint(6) NOT NULL COMMENT '分类ID',
  `language_id` smallint(6) NOT NULL COMMENT '语系ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `image` varchar(200) NOT NULL,
  `link` varchar(250) NOT NULL,
  `target` varchar(20) NOT NULL,
  `desc` text NOT NULL,
  `template` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `rewrite_url` varchar(100) NOT NULL,
  `seo_title` varchar(100) NOT NULL,
  `seo_keywords` varchar(100) NOT NULL,
  `seo_description` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- 转存表中的数据 `ko_catalog_language`
--

INSERT INTO `ko_catalog_language` (`id`, `catalog_id`, `language_id`, `title`, `image`, `link`, `target`, `desc`, `template`, `sort_order`, `rewrite_url`, `seo_title`, `seo_keywords`, `seo_description`) VALUES
(5, 2, 2, '關于我們', '', '', '', '', '', 0, '', '', '', ''),
(6, 2, 1, 'About Us', '', '', '_self', '', 'about_us', 0, '', '', '', ''),
(7, 9, 1, 'Home', '', '/', '_self', '', 'index', -1, '', '', '', ''),
(8, 3, 1, 'Services', '', '', '', '', '', 0, '', '', '', ''),
(9, 4, 1, 'Case', '', '', '', '', '', 0, '', '', '', ''),
(10, 5, 1, 'News', '', '', '', '', '', 0, '', '', '', ''),
(11, 6, 1, 'Contact Us', '', '', '_self', '', 'contact', 0, '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `ko_config`
--

CREATE TABLE IF NOT EXISTS `ko_config` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `module` varchar(20) NOT NULL,
  `language_id` smallint(6) NOT NULL,
  `key` varchar(100) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=100 ;

--
-- 转存表中的数据 `ko_config`
--

INSERT INTO `ko_config` (`id`, `module`, `language_id`, `key`, `value`) VALUES
(99, 'www', 1, 'theme', 'default'),
(37, 'www', 0, 'admin_email', '275986776@qq.com'),
(38, 'www', 0, 'is_open', '1'),
(39, 'www', 0, 'colse_why', ''),
(40, 'www', 0, 'rewrite', '1'),
(41, 'www', 0, 'upload_dir', ''),
(42, 'www', 0, 'debug', '1'),
(43, 'www', 0, 'name', 'PCAW'),
(44, 'www', 0, 'title', 'PC Accessories Wholesale Store'),
(45, 'www', 0, 'keywords', 'PC Accessories Wholesale Store'),
(46, 'www', 0, 'description', 'PC Accessories Wholesale Store'),
(47, 'www', 0, 'beian', ''),
(48, 'www', 0, 'copyright', ''),
(49, 'www', 0, 'mail_type', 'smtp'),
(50, 'www', 0, 'smtp_host', '123.123.123.1'),
(51, 'www', 0, 'smtp_port', ''),
(52, 'www', 0, 'smtp_account', '275986776@qq.com'),
(53, 'www', 0, 'smtp_password', '123456'),
(54, 'www', 0, 'logo', ''),
(55, 'www', 1, 'admin_email', '275986776@qq.com'),
(56, 'www', 1, 'is_open', '1'),
(57, 'www', 1, 'colse_why', ''),
(58, 'www', 1, 'rewrite', '1'),
(59, 'www', 1, 'upload_dir', ''),
(60, 'www', 1, 'debug', '1'),
(61, 'www', 1, 'name', 'PCAW'),
(62, 'www', 1, 'title', 'PC Accessories Wholesale Store'),
(63, 'www', 1, 'keywords', 'PC Accessories Wholesale Store'),
(64, 'www', 1, 'description', 'PC Accessories Wholesale Store'),
(65, 'www', 1, 'beian', ''),
(66, 'www', 1, 'copyright', ''),
(67, 'www', 1, 'mail_type', 'mail'),
(68, 'www', 1, 'smtp_host', 'smtp.exmail.qq.com'),
(69, 'www', 1, 'smtp_port', ''),
(70, 'www', 1, 'smtp_account', 'service@konasi.com'),
(71, 'www', 1, 'smtp_password', 'ling123456'),
(72, 'www', 1, 'logo', ''),
(73, 'www', 3, 'admin_email', '275986776@qq.com'),
(74, 'www', 3, 'is_open', '1'),
(75, 'www', 3, 'colse_why', ''),
(76, 'www', 3, 'rewrite', '1'),
(77, 'www', 3, 'upload_dir', ''),
(78, 'www', 3, 'debug', '1'),
(79, 'www', 3, 'name', 'PCAW'),
(80, 'www', 3, 'title', 'PC Accessories Wholesale Store'),
(81, 'www', 3, 'keywords', 'PC Accessories Wholesale Store'),
(82, 'www', 3, 'description', 'PC Accessories Wholesale Store'),
(83, 'www', 3, 'beian', ''),
(84, 'www', 3, 'copyright', ''),
(85, 'www', 3, 'mail_type', 'smtp'),
(86, 'www', 3, 'smtp_host', '123.123.123.1'),
(87, 'www', 3, 'smtp_port', ''),
(88, 'www', 3, 'smtp_account', '275986776@qq.com'),
(89, 'www', 3, 'smtp_password', '123456'),
(90, 'www', 3, 'logo', ''),
(93, 'www', 0, 'customer_service', 'a:5:{s:2:"qq";s:19:"409887775|云中龙";s:5:"skype";s:15:"asdfasd,sdfasdf";s:3:"msn";s:16:"asdfasdf@live.cn";s:5:"email";s:18:"dragonling@live.cn";s:3:"tel";s:12:"400-830-1234";}'),
(94, 'www', 3, 'customer_service', 'a:5:{s:2:"qq";s:9:"409887775";s:5:"skype";s:15:"asdfasd,sdfasdf";s:3:"msn";s:16:"asdfasdf@live.cn";s:5:"email";s:18:"dragonling@live.cn";s:3:"tel";s:12:"400-830-1234";}'),
(95, 'www', 0, 'about_us', '干枯'),
(98, 'www', 0, 'theme', 'default');

-- --------------------------------------------------------

--
-- 表的结构 `ko_config_language`
--

CREATE TABLE IF NOT EXISTS `ko_config_language` (
  `value` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `ko_feeback`
--

CREATE TABLE IF NOT EXISTS `ko_feeback` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `nickname` varchar(50) NOT NULL COMMENT '昵称',
  `email` varchar(100) NOT NULL COMMENT '电子信箱',
  `tel` char(20) NOT NULL COMMENT '电话/手机号',
  `qq` char(20) NOT NULL COMMENT 'QQ',
  `title` varchar(20) NOT NULL COMMENT '留言主题',
  `content` varchar(1000) NOT NULL COMMENT '留言内容',
  `reply` text NOT NULL COMMENT '回复内容',
  `act_time` int(11) NOT NULL COMMENT '留言时间',
  `reply_time` int(11) NOT NULL COMMENT '回复时间',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='留言馈' AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `ko_feeback`
--

INSERT INTO `ko_feeback` (`id`, `nickname`, `email`, `tel`, `qq`, `title`, `content`, `reply`, `act_time`, `reply_time`, `status`) VALUES
(1, '春风不度', '275986775@qq.com', '', '', 'asdfasdf', 'asdfasdfasdf', '', 0, 0, 1),
(2, 'afa', 'dragonling@live.cn', '13724230109', '', '', '13724230109', '13724230109', 1358696394, 0, 1),
(3, 'afa', 'dragonling@live.cn', '13724230109', '', '', '13724230109', '', 1358696517, 0, 1),
(4, 'afa', 'dragonling@live.cn', '13724230109', '', '', '13724230109', '', 1358696588, 0, 1),
(5, '春风不度', '275986776@qq.com', '13724230109', '', '', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud.', '', 1358846111, 0, 1),
(6, '春风不度', '275986776@qq.com', '', '', '', 'bbbbbbbbbbbbbbbbbbbbbbbb', '', 1358960009, 0, 1),
(7, '春风不度', '275986776@qq.com', '', '', '', 'nnnnnnnnnnnnnnnnnnnnnnnnn', '', 1358960069, 0, 1),
(8, '春风不度', '275986776@qq.com', '', '', '', 'jjjjjjjjjjjjjjjjjjjjjjjjjjjjjj', '', 1358960121, 0, 1),
(9, '春风不度', '275986776@qq.com', '', '', '', 'ffffffffffffffffffffffffffffffffffffffffffffffffff', '', 1358960290, 0, 1),
(10, '春风不度', '275986776@qq.com', '', '', '', 'sdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffsdfsfsdfsdfsdfsdf\n', '', 1358960371, 0, 1),
(11, '春风不度', '275986776@qq.com', '', '', '', 'sdfffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffsdfsfsdfsdfsdfsdf\n', '', 1358960501, 0, 1),
(12, '春风不度', '275986776@qq.com', '', '', '', 'asdfasdfasd', '', 1358960588, 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `ko_files`
--

CREATE TABLE IF NOT EXISTS `ko_files` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `name` varchar(200) NOT NULL DEFAULT '' COMMENT '文档',
  `alt` tinytext COMMENT '图片说明',
  `size` float NOT NULL DEFAULT '0' COMMENT '大小',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ko_friendly_links`
--

CREATE TABLE IF NOT EXISTS `ko_friendly_links` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `title` varchar(20) NOT NULL COMMENT '网站名',
  `link` varchar(100) NOT NULL COMMENT '链接',
  `image` varchar(100) NOT NULL COMMENT 'LOGO图片',
  `alt` varchar(100) NOT NULL COMMENT '备注',
  `name` char(20) NOT NULL COMMENT '联系人',
  `contact` varchar(100) NOT NULL COMMENT '联系方式',
  `sort_order` smallint(6) NOT NULL COMMENT '排序',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

--
-- 转存表中的数据 `ko_friendly_links`
--

INSERT INTO `ko_friendly_links` (`id`, `title`, `link`, `image`, `alt`, `name`, `contact`, `sort_order`, `status`) VALUES
(1, '获取视频分类', 'contactus', ',ecddc828a21c8db2b126b087fae140a6.jpg', 'd files', '全部', '275986776@qq.com', 99, 1),
(2, '获取视频分类', 'contactus', '', '', '', '275986776@qq.com', 0, 1),
(3, '获取视频分类', 'contactus', '', '', '全部', '275986776@qq.com', 0, 1),
(4, '聚合视频列表', '/services', '', '', '', '275986776@qq.com', 0, 1),
(5, '获取视频分类', 'contactus', '', '', '', '275986776@qq.com', 0, 1),
(6, '视频详情', 'contactus', '', '', '', '275986776@qq.com', 0, 1),
(7, '自定义内容区', '/services', '', '', '', '275986776@qq.com', 0, 1);

-- --------------------------------------------------------

--
-- 表的结构 `ko_languages`
--

CREATE TABLE IF NOT EXISTS `ko_languages` (
  `id` tinyint(4) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `code` char(2) NOT NULL COMMENT '代码',
  `name` varchar(20) NOT NULL COMMENT '名称',
  `charset` varchar(20) NOT NULL COMMENT '编码',
  `pack_name` varchar(20) NOT NULL COMMENT '语言包名',
  `icon` varchar(100) NOT NULL COMMENT '国标',
  `status` tinyint(4) NOT NULL DEFAULT '0' COMMENT '状态',
  PRIMARY KEY (`id`),
  UNIQUE KEY `ID` (`code`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 PACK_KEYS=0 AUTO_INCREMENT=13 ;

--
-- 转存表中的数据 `ko_languages`
--

INSERT INTO `ko_languages` (`id`, `code`, `name`, `charset`, `pack_name`, `icon`, `status`) VALUES
(1, 'US', 'English', 'utf-8', 'en/us/', '/assets/flags/us.png', 1),
(2, 'HK', '繁體中文', 'Big5', 'zh/hk/', '/assets/flags/hk.png', 1),
(3, 'CN', '简体中文', 'GB2312', 'zh/cn/', '/assets/flags/cn.png', 1),
(4, 'JP', 'にほんご', 'Shift-JIS', '', '', 0),
(5, 'SP', 'España', 'utf-8', '', '', 0),
(6, 'FG', 'Figure', 'FG', '', '', 0),
(7, 'OP', 'Operator', 'ope001', '', '', 0),
(8, 'SA', 'España', 'utf-8', '', '', 0);

-- --------------------------------------------------------

--
-- 表的结构 `ko_product`
--

CREATE TABLE IF NOT EXISTS `ko_product` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category_id` smallint(6) NOT NULL COMMENT '分类',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `desc` varchar(1000) NOT NULL COMMENT '简述/卖点',
  `model` varchar(100) NOT NULL COMMENT '型号',
  `thumb` varchar(100) NOT NULL COMMENT '列表图',
  `images` varchar(1000) NOT NULL COMMENT '相册',
  `is_featured` tinyint(2) NOT NULL DEFAULT '0' COMMENT '特色产品',
  `is_new` tinyint(2) NOT NULL DEFAULT '0' COMMENT '新产品',
  `sort_order` int(11) NOT NULL COMMENT '排序',
  `status` tinyint(2) NOT NULL COMMENT '状态',
  `template` varchar(100) NOT NULL COMMENT '模板',
  `rewrite_url` varchar(100) NOT NULL COMMENT 'URL重写',
  `seo_title` varchar(100) NOT NULL COMMENT 'SEO标题',
  `seo_keywords` varchar(200) NOT NULL COMMENT '关键词',
  `seo_description` varchar(200) NOT NULL COMMENT '简述',
  `create_time` int(11) NOT NULL COMMENT '创建时间',
  `update_time` int(11) NOT NULL COMMENT '更新时间',
  `last_admin_user` int(11) NOT NULL COMMENT '最后修改人',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COMMENT='产品主表' AUTO_INCREMENT=39 ;

--
-- 转存表中的数据 `ko_product`
--

INSERT INTO `ko_product` (`id`, `category_id`, `title`, `desc`, `model`, `thumb`, `images`, `is_featured`, `is_new`, `sort_order`, `status`, `template`, `rewrite_url`, `seo_title`, `seo_keywords`, `seo_description`, `create_time`, `update_time`, `last_admin_user`) VALUES
(1, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', '/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg,', 0, 0, 0, 1, '', '', '', 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', 0, 0, 0),
(2, 3, '新新''C"PU', '', '/assets/uploads/products/201301/952462b04fb38a6e96a1cc435bfd2d84.jpg', '/assets/uploads/products/201301/08b447e88aecf96b22e9e60529f53723.jpg', '/assets/uploads/products/201301/7965a3d33a76bf024e0116a7cb7fd8dc.jpg,/assets/uploads/products/201301/53b66feb70292c59e4f0c4596170dd20.jpg,', 0, 0, 0, 1, '', '', '', 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', 0, 0, 0),
(3, 1, '获取视频分类', '', '511890a31,3339c800fba"1c977ee4da31.txt', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg,/assets/uploads/products/201301/08b447e88aecf96b22e9e60529f53723.jpg,/assets/uploads/products/201301/521a9b850481e242f8bcf783df7ca61a.jpg,', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(4, 1, '获取视频分类', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(5, 1, '获取视频分类', '', '111', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(6, 1, '获取视频分类', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(7, 1, '获取视频分类', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(8, 1, '获取视频分类', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(9, 1, '获取视频分类', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(10, 1, '获取视频分类', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(11, 1, '获取视频分类', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(12, 1, '自定义内容区', '', '12322', '/assets/uploads/products/201301/21c65fc07bdd22e60ac4033a24695e52.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(13, 1, '聚合视频列表', '', '12322', '/assets/uploads/products/201301/ab00dc2c684b366c0fd4a99b79137c71.jpg', '', 1, 1, 0, 1, '', '', '', '', '', 0, 0, 0),
(14, 3, 'ttset', '', 'tset', '', '', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(15, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(16, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(17, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(18, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(19, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(20, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(21, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(22, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(23, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(24, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(25, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(26, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(27, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(28, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(29, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(30, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(31, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(32, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(33, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(34, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(35, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(36, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(37, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0),
(38, 1, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '111', '/assets/uploads/products/201301/bc9a75b17b40b2651c87375b818125df.jpg', ',/assets/uploads/products/201301/27aa3a36e39548117bd0ab2e5b4e658c.jpg,/assets/uploads/products/201301/0a84d222998812487aac3fa4413105dd.jpg,/assets/uploads/products/201301/7abf063ab8f76bfd30cccd6f7d21f3de.jpg,/assets/uploads/products/201301/3ecec48c5c2f3d744059f272006aeb99.jpg,/assets/uploads/products/201301/e511eaf3cd40e0ac558d05694c532fd0.jpg,/assets/uploads/products/201301/29799848fa30496519d41ef4f3a742e4.jpg', 0, 0, 0, 1, '', '', '', '', '', 0, 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `ko_product_catalog`
--

CREATE TABLE IF NOT EXISTS `ko_product_catalog` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `product_id` int(11) NOT NULL COMMENT '产品',
  `catalog_id` smallint(6) NOT NULL COMMENT '栏目ID',
  `sort_order` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `product_id` (`product_id`,`catalog_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `ko_product_catalog`
--

INSERT INTO `ko_product_catalog` (`id`, `product_id`, `catalog_id`, `sort_order`) VALUES
(3, 1, 3, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `ko_product_category`
--

CREATE TABLE IF NOT EXISTS `ko_product_category` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `parent_id` smallint(6) NOT NULL COMMENT '父ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `image` varchar(200) NOT NULL COMMENT '图片',
  `target` varchar(20) NOT NULL COMMENT '打开方式',
  `desc` text NOT NULL COMMENT '描述',
  `template` varchar(100) NOT NULL COMMENT '模板',
  `sort_order` smallint(6) NOT NULL DEFAULT '50' COMMENT '排序',
  `status` tinyint(4) NOT NULL COMMENT '状态',
  `rewrite_url` varchar(100) NOT NULL COMMENT '自定义链接',
  `seo_title` varchar(100) NOT NULL COMMENT '标题',
  `seo_keywords` varchar(100) NOT NULL COMMENT '关键字',
  `seo_description` varchar(200) NOT NULL COMMENT '简述',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `ko_product_category`
--

INSERT INTO `ko_product_category` (`id`, `parent_id`, `title`, `image`, `target`, `desc`, `template`, `sort_order`, `status`, `rewrite_url`, `seo_title`, `seo_keywords`, `seo_description`) VALUES
(1, 0, '电脑', '', '_self', '', '', 0, 1, '', '', '', ''),
(2, 0, '手机', '', '_self', '', '', 0, 1, '', '', '', ''),
(3, 0, '数码相机', '', '_self', '', '', 0, 1, '', '', '', ''),
(4, 1, 'CPU', '', '_self', '', '', 0, 1, '', '', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `ko_product_category_language`
--

CREATE TABLE IF NOT EXISTS `ko_product_category_language` (
  `id` smallint(6) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `category_id` smallint(6) NOT NULL COMMENT '分类ID',
  `language_id` smallint(6) NOT NULL COMMENT '语系ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `image` varchar(200) NOT NULL,
  `link` varchar(250) NOT NULL,
  `target` varchar(20) NOT NULL,
  `desc` text NOT NULL,
  `template` varchar(100) NOT NULL,
  `sort_order` int(11) NOT NULL,
  `rewrite_url` varchar(100) NOT NULL,
  `seo_title` varchar(100) NOT NULL,
  `seo_keywords` varchar(100) NOT NULL,
  `seo_description` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ko_product_contents`
--

CREATE TABLE IF NOT EXISTS `ko_product_contents` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `product_id` int(11) NOT NULL COMMENT '主贴',
  `language_id` smallint(6) NOT NULL COMMENT '语系ID',
  `title` varchar(20) NOT NULL COMMENT '标题',
  `image` varchar(100) NOT NULL COMMENT '图片',
  `content` text NOT NULL COMMENT '内容',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `ko_product_contents`
--

INSERT INTO `ko_product_contents` (`id`, `product_id`, `language_id`, `title`, `image`, `content`) VALUES
(1, 1, 0, '描述', '', '<div class="mod_detail_info id_intro" style="margin:0px auto;padding:35px 0px 0px;color:#444444;font-family:Arial, Simsun, Helvetica;background-color:#FFFFFF;">\n	<div class="mod_hd" style="margin:0px;padding:0px;font-size:14px;font-family:微软雅黑, SimSun;color:#666666;">\n		<h3 style="font-size:14px;">\n			<span class="tit" style="font-weight:normal;font-size:18px;font-family:微软雅黑, SimHei;color:#2457A6;vertical-align:middle;">商品简介</span>一句话，就是精品\n		</h3>\n<i class="line"></i> \n	</div>\n	<div class="mod_bd" style="margin:0px;padding:20px 0px 40px;">\n		<p style="text-align:center;">\n			<img alt="" src="http://img2.icson.com/details/59/419/59-419-654-20120717-0.jpg" style="width:740px;" /> \n		</p>\n		<p>\n			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp; 出色的便携式产品拥有高端处理器与显卡，实现快如闪电的性能与持久可靠的数据存储。能够加速启动，减少应用装载时间！\n		</p>\n	</div>\n</div>\n<div class="mod_detail_info id_features" style="margin:0px auto;padding:35px 0px 0px;color:#444444;font-family:Arial, Simsun, Helvetica;background-color:#FFFFFF;">\n	<div class="mod_hd" style="margin:0px;padding:0px;font-size:14px;font-family:微软雅黑, SimSun;color:#666666;">\n		<h3 style="font-size:14px;">\n			<span class="tit" style="font-weight:normal;font-size:18px;font-family:微软雅黑, SimHei;color:#2457A6;vertical-align:middle;">商品特性</span>产品描述仅供参考，具体请查看规格参数\n		</h3>\n<i class="line"></i> \n	</div>\n	<div class="mod_bd" style="margin:0px;padding:20px 0px 40px;">\n		<p style="text-align:center;">\n			<img alt="" src="http://img2.icson.com/details/59/419/59-419-654-20120717-1.jpg" style="width:723px;height:1631px;" /> \n		</p>\n		<p align="right">\n			<span>*本产品介绍为 ThinkPad 联想 T 系列全系介绍，具体功能参数请以实际产品为准！</span> \n		</p>\n	</div>\n</div>\n<div class="mod_detail_info id_pic" style="margin:0px auto;padding:35px 0px 0px;color:#444444;font-family:Arial, Simsun, Helvetica;background-color:#FFFFFF;">\n	<div class="mod_hd" style="margin:0px;padding:0px;font-size:14px;font-family:微软雅黑, SimSun;color:#666666;">\n		<h3 style="font-size:14px;">\n			<span class="tit" style="font-weight:normal;font-size:18px;font-family:微软雅黑, SimHei;color:#2457A6;vertical-align:middle;">精美图片</span> \n		</h3>\n<i class="line"></i> \n	</div>\n	<div class="mod_bd" style="margin:0px;padding:20px 0px 40px;">\n		<p style="text-align:center;">\n			<img alt="" src="http://img2.icson.com/product/mpic/79/419/79-419-052.jpg" style="width:560px;" /> \n		</p>\n		<p style="text-align:center;">\n			<img alt="" src="http://img2.icson.com/product/mpic/79/419/79-419-052-01.jpg" style="width:560px;" /> \n		</p>\n		<p style="text-align:center;">\n			<img alt="" src="http://img2.icson.com/product/mpic/79/419/79-419-052-02.jpg" style="width:560px;" /> \n		</p>\n		<p style="text-align:center;">\n			<img alt="" src="http://img2.icson.com/product/mpic/79/419/79-419-052-03.jpg" style="width:560px;" /> \n		</p>\n	</div>\n</div>\n<div id="id_link" class="mod_detail_info id_link" style="margin:0px auto;padding:35px 0px 0px;color:#444444;font-family:Arial, Simsun, Helvetica;background-color:#FFFFFF;">\n	<div class="mod_hd" style="margin:0px;padding:0px;font-size:14px;font-family:微软雅黑, SimSun;color:#666666;">\n		<h3 style="font-size:14px;">\n			<span class="tit" style="font-weight:normal;font-size:18px;font-family:微软雅黑, SimHei;color:#2457A6;vertical-align:middle;">相关说明</span> \n		</h3>\n<i class="line"></i> \n	</div>\n	<div class="mod_bd" style="margin:0px;padding:20px 0px 40px;">\n		<table align="center" border="0" cellpadding="1" cellspacing="10" class="cssback_table ke-zeroborder" width="740" style="border-collapse:separate;">\n			<tbody>\n				<tr>\n					<td>\n						<img src="http://img2.icson.com/details/99/219/99-219-507-20120906-0.jpg" /> \n					</td>\n					<td>\n						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<strong>ThinkPad</strong>，中文名为“思考本”， 在2005年以前是IBM PC事业部旗下的便携式计算机品牌，凭借坚固和可靠的特性在业界享有很高声誉。在Lenovo收购IBM PC事业部之后，ThinkPad商标为Lenovo所有。ThinkPad自问世以来一直保持着黑色的经典外观并对技术有着自己独到的见解，如：TrackPoint（指点杆，俗称小红点）、ThinkLight键盘灯、全尺寸键盘和APS(Active Protection System，主动保护系统)。\n					</td>\n				</tr>\n			</tbody>\n		</table>\n	</div>\n</div>'),
(2, 1, 0, '规格参数', '', '<table cellpadding="0" cellspacing="0" class="specification" style="color:#444444;font-family:Arial, Simsun, Helvetica;font-size:12px;text-align:left;background-color:#FFFFFF;">\n	<tbody>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				基本参数\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				品牌\n			</td>\n			<td class="desc">\n				ThinkPad 联想\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				型号\n			</td>\n			<td class="desc">\n				T430i（23423RC）\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				移动平台\n			</td>\n			<td class="desc">\n				Intel 平台\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				主板芯片组\n			</td>\n			<td class="desc">\n				英特尔儀M77芯片组\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				CPU型号\n			</td>\n			<td class="desc">\n				I3-2328\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				CPU主频\n			</td>\n			<td class="desc">\n				2.2GHz\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				CPU描述\n			</td>\n			<td class="desc">\n				第二代英特尔 酷睿 i3-2328M处理器(2.2GHz)\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				三级缓存\n			</td>\n			<td class="desc">\n				3 M\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				显示屏\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				显示屏尺寸\n			</td>\n			<td class="desc">\n				14英寸\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				显示屏类别\n			</td>\n			<td class="desc">\n				LED背光\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				存储设备\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				内存容量\n			</td>\n			<td class="desc">\n				2GB\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				内存类型\n			</td>\n			<td class="desc">\n				DDR3 1600MHz\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				备注\n			</td>\n			<td class="desc">\n				内存实际运行频率与芯片组及CPU频率有关。\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				硬盘类型\n			</td>\n			<td class="desc">\n				SATA硬盘\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				硬盘参数\n			</td>\n			<td class="desc">\n				7200转\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				硬盘\n			</td>\n			<td class="desc">\n				500G\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				音频视频\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				显示类型\n			</td>\n			<td class="desc">\n				核心显卡\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				显卡型号\n			</td>\n			<td class="desc">\n				英特尔 HD 3000显示芯片\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				扬声器\n			</td>\n			<td class="desc">\n				内置扬声器\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				通　　讯\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				网卡\n			</td>\n			<td class="desc">\n				内置10-100-1000M网卡\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				无线网卡\n			</td>\n			<td class="desc">\n				802.11b/g/n\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				蓝牙\n			</td>\n			<td class="desc">\n				蓝牙\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				摄像头\n			</td>\n			<td class="desc">\n				720p HD 摄像头\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				输入输出\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				鼠标替代设备\n			</td>\n			<td class="desc">\n				触摸板\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				读卡器\n			</td>\n			<td class="desc">\n				4合一读卡器\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				其它接口\n			</td>\n			<td class="desc">\n				2个USB 3.0，1个Powered USB 2.0，1个USB 2.0，VGA DB-15，Mini DisplayPort，RJ-45，耳机&amp;麦克风组合接口，四合一读卡器和34mm Express卡插槽\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				键盘\n			</td>\n			<td class="desc">\n				标准\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				结构特征\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				其　　它\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				操作系统\n			</td>\n			<td class="desc">\n				正版 Windows 7 家庭普通版 64位\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				附件\n			</td>\n			<td class="desc">\n				原厂包装配件\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				电池规格\n			</td>\n			<td class="desc">\n				6芯锂电池\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				续航时间\n			</td>\n			<td class="desc">\n				6小时左右\n			</td>\n		</tr>\n		<tr>\n			<td colspan="2" class="title" style="background-color:#F0F0F0;font-weight:bold;">\n				保修及在线支持\n			</td>\n		</tr>\n		<tr>\n			<td class="name">\n				概述\n			</td>\n			<td class="desc">\n				产品免费保修期内，您在中华人民共和国境内（不包括港、澳、台地区）购买并使用的联想公司在中国大陆地区正式发布的产品出现本服务承诺责任范围内的硬件故障，请您首先拨打联想Think报修热线进行报修。保修期限以您购买的产品随机保卡上标注的保修期限为准。保卡不补发，保修期内请妥善保管。\n			</td>\n		</tr>\n	</tbody>\n</table>'),
(3, 1, 0, '售后', '', '<div class="i_hd" style="margin:0px;padding:8px 0px 7px 10px;background-color:#FFFFFF;border:1px solid #FFFFFF;color:#444444;font-family:Arial, Simsun, Helvetica;">\n	<h3 style="font-size:14px;">\n		保修条款\n	</h3>\n</div>\n<div class="i_bd" style="margin:0px;padding:10px 38px 22px;color:#444444;font-family:Arial, Simsun, Helvetica;background-color:#FFFFFF;">\n	<p>\n		<span style="font-weight:bold;font-size:13px;">一年保修</span><br />\n<br />\n1.联系联想：400-100-6000（周一至周五8:30-17:30）；电脑售后问题还可咨询联想服务官方微信（周一至周日9:00-21:00），在微信添加朋友功能中搜号码1131390901或LenovoServices，添加联想服务官方微信，电脑售后问题随时随地咨询。<a href="http://support1.lenovo.com.cn/lenovo/wsi/contact.html?intcmp=I_F_51buy_Think_5" target="_blank"><u>点击查看更多联系方式&gt;&gt;</u></a><br />\n<br />\n2.服务网点：全国两千多家网点<a href="http://think.lenovo.com.cn/stations/thinkServiceStation.aspx?intcmp=I_F_51buy_Think_1" target="_blank"><u>点击查看服务网点信息&gt;&gt;</u></a> \n	</p>\n</div>'),
(4, 14, 0, 'New', '', '1515153');

-- --------------------------------------------------------

--
-- 表的结构 `ko_product_language`
--

CREATE TABLE IF NOT EXISTS `ko_product_language` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `product_id` int(11) NOT NULL COMMENT '产品ID',
  `language_id` smallint(6) NOT NULL COMMENT '语系ID',
  `title` varchar(100) NOT NULL COMMENT '标题',
  `description` varchar(250) NOT NULL COMMENT '简述',
  `keywords` varchar(200) NOT NULL COMMENT '关键词',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `ko_product_language`
--

INSERT INTO `ko_product_language` (`id`, `product_id`, `language_id`, `title`, `description`, `keywords`) VALUES
(1, 1, 3, 'Thinkpad 联想 T430i（23423RC）14英寸笔记本电脑 I3-2328/2G/500G/核心显卡/指纹/摄像头/蓝牙/window7', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `ko_roles`
--

CREATE TABLE IF NOT EXISTS `ko_roles` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(32) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_name` (`name`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- 转存表中的数据 `ko_roles`
--

INSERT INTO `ko_roles` (`id`, `name`, `description`) VALUES
(1, 'login', 'Login privileges, granted after account confirmation'),
(2, 'admin', 'Administrative user, has access to everything.');

-- --------------------------------------------------------

--
-- 表的结构 `ko_roles_users`
--

CREATE TABLE IF NOT EXISTS `ko_roles_users` (
  `user_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `fk_role_id` (`role_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `ko_roles_users`
--

INSERT INTO `ko_roles_users` (`user_id`, `role_id`) VALUES
(1, 1),
(3, 1),
(4, 1),
(5, 1),
(1, 2),
(2, 2),
(3, 2),
(5, 2);

-- --------------------------------------------------------

--
-- 表的结构 `ko_sys_cache_tag`
--

CREATE TABLE IF NOT EXISTS `ko_sys_cache_tag` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `tag` varchar(50) DEFAULT NULL COMMENT 'Tag标示',
  `name` varchar(50) DEFAULT NULL COMMENT 'Tag名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `ko_sys_cache_tag`
--

INSERT INTO `ko_sys_cache_tag` (`id`, `tag`, `name`) VALUES
(2, 'TAO_LIST', '淘宝商品列表'),
(3, 'TREEVIEWS_DATA', '树状数据'),
(4, 'DATA_CATALOG', '栏目缓存');

-- --------------------------------------------------------

--
-- 表的结构 `ko_users`
--

CREATE TABLE IF NOT EXISTS `ko_users` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(127) NOT NULL,
  `username` varchar(32) NOT NULL DEFAULT '',
  `password` char(64) NOT NULL,
  `logins` int(10) unsigned NOT NULL DEFAULT '0',
  `last_login` int(10) unsigned DEFAULT NULL,
  `reset_token` char(64) NOT NULL DEFAULT '',
  `status` varchar(20) NOT NULL DEFAULT '',
  `last_failed_login` datetime NOT NULL,
  `failed_login_count` int(11) NOT NULL DEFAULT '0',
  `created` datetime NOT NULL,
  `modified` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_username` (`username`),
  UNIQUE KEY `uniq_email` (`email`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=20 ;

--
-- 转存表中的数据 `ko_users`
--

INSERT INTO `ko_users` (`id`, `email`, `username`, `password`, `logins`, `last_login`, `reset_token`, `status`, `last_failed_login`, `failed_login_count`, `created`, `modified`) VALUES
(1, 'smeng@vlctech.com', 'admin222', 'c8eb2cfbc1f802956bddbc5388e21b3fe8204a6094e4cba6f74b608921adda27', 540, 1363424126, '', '', '2012-04-11 17:45:40', 0, '2011-11-20 03:18:32', '2012-07-09 14:10:26'),
(2, 'admin@example.com', 'mengshuai', '2560f69bcee7277e1670cba1dd24b57bad4bfe5f415fcfb9648c93ca12b3cd21', 0, NULL, '', '', '2011-11-20 04:09:11', 3, '2011-11-20 03:28:15', '2011-11-20 04:09:11'),
(3, 's@vlctech.com', 'shunnar', '38a923890e75ccde333794b8346cb0efac0248ec7d095d6d0c92fbeb70ddc0c4', 42, 1322551534, '', '', '2011-11-30 15:41:11', 1, '2011-11-20 04:10:10', '2011-11-30 15:41:11'),
(4, 'mengshuai@1.cn', 'smeng', 'c8eb2cfbc1f802956bddbc5388e21b3fe8204a6094e4cba6f74b608921adda27', 1, 1321845798, '', '', '0000-00-00 00:00:00', 0, '2011-11-21 11:23:18', '2011-11-21 11:23:18'),
(5, 'htxie@vlctech.com', 'htxie', '5dc163d62b5d929d8a5a933cb360263695ff2fb4d11fce699e087f9003bc1a2e', 141, 1340076905, '', '', '2012-02-20 15:02:31', 0, '2012-02-20 14:12:13', '2012-04-27 08:55:34'),
(6, 'dragonling@live.cn', 'feilong', 'bc5df3c3b1f0904df197acfd73863e868826d9b1f8f0b6ed557be1d9eeca22fa', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'dragonlingasdfasdf@lives.cn', 'feilonga', '5e26eeb109589fa783de6480149e169c6250bdcd34cb7040c715f98dbf8ea55c', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'dragonling2@live.cn', 'dragonling2@live.cn', '2560f69bcee7277e1670cba1dd24b57bad4bfe5f415fcfb9648c93ca12b3cd21', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'dragonling32@live.cn', 'dragonling2@livde.cn', '2560f69bcee7277e1670cba1dd24b57bad4bfe5f415fcfb9648c93ca12b3cd21', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'dragonling22@live.cn', 'feilongaa', '2560f69bcee7277e1670cba1dd24b57bad4bfe5f415fcfb9648c93ca12b3cd21', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'dragonlings@live.cn', 'adsfasfd', 'f72bc6518b976bfe1386abf354d807579f9f5ca508749f119189d00a6037d0a8', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'dragonlingsk@live.cn', 'adsfasfdk', '4e7039e7629c60b2c120fcb309070981a7ee647aceac8222e07bec0ecfc9d012', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(14, 'dragonlingska@live.cn', 'asfasdf', 'f72bc6518b976bfe1386abf354d807579f9f5ca508749f119189d00a6037d0a8', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(15, 'dragonlings11@live.cn', 'aaabb', '2560f69bcee7277e1670cba1dd24b57bad4bfe5f415fcfb9648c93ca12b3cd21', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(16, 'dragonlings1d1@live.cn', 'aaabba', 'f72bc6518b976bfe1386abf354d807579f9f5ca508749f119189d00a6037d0a8', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(17, 'dragonlings1da1@live.cn', 'aaabbaa', '2560f69bcee7277e1670cba1dd24b57bad4bfe5f415fcfb9648c93ca12b3cd21', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(18, 'dragonlings1daaa1@live.cn', 'dragonlings1daaa1@live.cn', '80596762b89da57ee6317f34f0b348c34fb58deb2cdac9a9717c64df50c49e5a', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(19, 'dra@live.cn', 'dra@live.cn', 'f72bc6518b976bfe1386abf354d807579f9f5ca508749f119189d00a6037d0a8', 0, NULL, '', '', '0000-00-00 00:00:00', 0, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- 表的结构 `ko_user_identities`
--

CREATE TABLE IF NOT EXISTS `ko_user_identities` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `provider` varchar(255) NOT NULL,
  `identity` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_indentity` (`provider`,`identity`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- 表的结构 `ko_user_info`
--

CREATE TABLE IF NOT EXISTS `ko_user_info` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `user_id` int(11) DEFAULT NULL COMMENT 'User ID',
  `first_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '姓',
  `last_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '名',
  `gender` tinyint(2) DEFAULT NULL COMMENT '性別',
  `brithday` date DEFAULT NULL COMMENT '出生日期',
  `phone` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '手提電話',
  `spare_email` varchar(200) CHARACTER SET utf8 DEFAULT NULL COMMENT '備用電郵',
  `id_card` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '香港身份證號碼',
  `county` smallint(6) DEFAULT NULL COMMENT '來自',
  `education` smallint(6) DEFAULT NULL COMMENT '教育程度',
  `profession` smallint(6) DEFAULT NULL COMMENT '職業',
  `income` smallint(6) DEFAULT NULL COMMENT '個人收入',
  `family_income` smallint(6) DEFAULT NULL COMMENT '家庭收入',
  `marriage` tinyint(2) DEFAULT NULL COMMENT '婚姻狀況',
  `referrer` tinyint(2) NOT NULL DEFAULT '0' COMMENT '會員推薦',
  `referrer_name` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '推薦人',
  `referrer_id` varchar(4) CHARACTER SET utf8 DEFAULT NULL COMMENT '推薦人編號',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_id` (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_bin AUTO_INCREMENT=14 ;

--
-- 转存表中的数据 `ko_user_info`
--

INSERT INTO `ko_user_info` (`id`, `user_id`, `first_name`, `last_name`, `gender`, `brithday`, `phone`, `spare_email`, `id_card`, `county`, `education`, `profession`, `income`, `family_income`, `marriage`, `referrer`, `referrer_name`, `referrer_id`) VALUES
(7, 14, 'asfasdf', '', 1, '0000-00-00', '', '', '', 0, 0, 0, 0, 0, 0, 0, '', ''),
(9, NULL, 'aaabba', '暗暗啊', 1, '1987-04-15', '8613724230109', '1111@asdf.com', '12121212', 1, 1, 2, 2, 2, 1, 0, 'aaa', 'bbb'),
(10, 17, 'aaabbaa', '暗暗啊', 1, '1987-04-15', '8613724230109', '1111@asdf.com', '12121212', 1, 1, 2, 2, 2, 1, 0, 'aaa', 'bbb'),
(11, 18, 'feilong', 'ling', 1, '1987-04-15', '8613724230109', '1111@asdf.com', '12121212', 1, 1, 2, 2, 2, 1, 0, 'aaa', 'bbb'),
(12, 19, '凌', '飛龍', 1, '1987-04-15', '8613724230109', '1111@asdf.com', '12121212', 1, 1, 2, 2, 2, 1, 0, 'aaa', 'bbb'),
(13, 1, 'Ling凌', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `ko_user_tokens`
--

CREATE TABLE IF NOT EXISTS `ko_user_tokens` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) unsigned NOT NULL,
  `user_agent` varchar(40) NOT NULL,
  `token` varchar(40) NOT NULL,
  `created` int(10) unsigned NOT NULL,
  `expires` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uniq_token` (`token`),
  KEY `fk_user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- 限制导出的表
--

--
-- 限制表 `ko_roles_users`
--
ALTER TABLE `ko_roles_users`
  ADD CONSTRAINT `ko_roles_users_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ko_users` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `ko_roles_users_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `ko_roles` (`id`) ON DELETE CASCADE;

--
-- 限制表 `ko_user_identities`
--
ALTER TABLE `ko_user_identities`
  ADD CONSTRAINT `ko_user_identities_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ko_users` (`id`) ON DELETE CASCADE;

--
-- 限制表 `ko_user_tokens`
--
ALTER TABLE `ko_user_tokens`
  ADD CONSTRAINT `ko_user_tokens_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `ko_users` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
