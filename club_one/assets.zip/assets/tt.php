<!DOCTYPE html>
<html>
<head>
<meta name="viewport" content="initial-scale=1.0, user-scalable=no" />
<style type="text/css">
  html { height: 100% }
  body { height: 100%; margin: 0px; padding: 0px }
  #map_canvas { height: 100% }
</style>
<script type="text/javascript" src="https://maps.google.com/maps/api/js?sensor=false"></script>
<script>
var map;
function initialize() {
  var myLatlng = new google.maps.LatLng(22.650355786137453, 114.01300579999997);
  var myOptions = {
    zoom: 13,
    center: myLatlng,
    mapTypeId: google.maps.MapTypeId.ROADMAP
  }

  map = new google.maps.Map(document.getElementById("map_canvas"), myOptions);

  // Add 5 markers to the map at random locations
  var southWest = new google.maps.LatLng(22.650355786137453, 114.01300579999997);
  var northEast = new google.maps.LatLng(22.643508149449538, 114.01128187829589);
  
	var marker = new google.maps.Marker({
		position: southWest, 
		map: map
	});
	marker.setTitle('���ٹ��@');
	attachSecretMessage(marker, '���ٹ��@');
	
	var marker = new google.maps.Marker({
		position: northEast, 
		map: map
	});
	marker.setTitle('���ٵ��F');
	attachSecretMessage(marker, '���ٵ��F');

}

// The five markers show a secret message when clicked
// but that message is not within the marker's instance data

function attachSecretMessage(marker, message) {
  var infowindow = new google.maps.InfoWindow(
      { content: message,
        size: new google.maps.Size(50,50)
      });
  google.maps.event.addListener(marker, 'click', function() {
    infowindow.open(map,marker);
  });
}
function get_zoom()
{
	alert(map.zoom);
}
</script>
</head>
<body onload="initialize()">
  <div id="map_canvas" style="width:700px; height:500px" onmouseout="get_zoom()"></div>
</body>
</html>
