<?php defined('SYSPATH') or die('No direct access allowed.');
 
return array(
 
    'driver'       => 'orm',
    'hash_method'  => 'sha256',
    'hash_key'     => 'Never gonna give you up',
    'lifetime'     => 1209600,
    'session_key'  => 'auth_user',
    'session_type' =>'native'
);  