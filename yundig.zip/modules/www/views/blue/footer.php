		</div>
	</div>
   <!-- footer -->
   <div id="footer">
   	<div class="container">
      	<ul class="nav">
         	<li><a href="index.html">Home</a>|</li>
            <li><a href="about-us.html">About Us</a>|</li>
            <li><a href="solutions.html">Solutions</a>|</li>
            <li><a href="partners.html">Partners</a>|</li>
            <li><a href="consulting.html">Consulting</a>|</li>
            <li><a href="contact-us.html">Contact Us</a></li>
         </ul>
         <div class="wrapper">
         	<div class="fleft">Copyright &copy; 2009</div>
            <div class="fright"><a href="http://www.cssmoban.com/flash-templates.php">Flash Templates</a> from TemplateMonster - Squeeze Your Competitors.</div>
         </div>
      </div>
   </div>
</body>
</html>