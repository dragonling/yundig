<?php echo View::factory('header') ?>    
    
<!-- box begin -->
 <div class="box">
	<div class="border-top">
	   <div class="border-right">
		  <div class="border-bot">
			 <div class="border-left">
				<div class="left-top-corner">
				   <div class="right-top-corner">
					  <div class="right-bot-corner">
						 <div class="left-bot-corner">
							<div class="inner">
							   <h2>Proud to Be a Partner</h2>
							   <p>Nothing is as good at showing your company’s advantages as a nice list of partners. Below is a perfect way to present this list - with partners’ company names, logos and short desriptions.</p>
							   <ul class="list2">
								  <li>
									 <img alt="" src="images/image_76x76.gif" />
									 <h4><strong>Doodle Inc.</strong></h4>
									 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								  </li>
								  <li>
									 <img alt="" src="images/image_76x76.gif" />
									 <h4><strong>Macrohard</strong></h4>
									 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								  </li>
								  <li>
									 <img alt="" src="images/image_76x76.gif" />
									 <h4><strong>A-Bode</strong></h4>
									 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								  </li>
								  <li>
									 <img alt="" src="images/image_76x76.gif" />
									 <h4><a href="http://www.templatemonster.com" target="_blank"><strong>TemplateMonster</strong></a></h4>
									 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								  </li>
								  <li>
									 <img alt="" src="images/image_76x76.gif" />
									 <h4><strong>GoMommy</strong></h4>
									 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								  </li>
								  <li>
									 <img alt="" src="images/image_76x76.gif" />
									 <h4><strong>Lola-Cola</strong></h4>
									 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								  </li>
								  <li>
									 <img alt="" src="images/image_76x76.gif" />
									 <h4><strong>Colonel Motors</strong></h4>
									 Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
								  </li>
							   </ul>
							</div>
						 </div>
					  </div>
				   </div>
				</div>
			 </div>
		  </div>
	   </div>
	</div>
 </div>
 <!-- box end -->
		
<?php echo View::factory('footer') ?>