this is <?php echo Kohana::$config->load('site')->get('theme') ?> home
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>
<?php echo Kohana::$base_url ?>