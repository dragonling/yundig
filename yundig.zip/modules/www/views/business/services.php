<?php echo View::factory('header') ?>
    
    	<h2>Our Services</h2>
        
        <p>Cum sociis natoque penatibus et magnis dis <a href="#">parturient montes</a>, nascetur ridiculus mus. Praesent aliquam velit a magna sodales quis elementum ipsum auctor. Duis quis mi erat.</p>
        
      <div class="cleaner_h30"></div>
    
        <div class="services_section">
        
            <h4>Curabitur at risus sit amet risus</h4>

            <div class="services_content">
            
            	<div class="left">
               		<a href="#"><img src="<?php echo Kohana::$base_url ?>assets/themes/business/images//service_01.png" alt="image" /></a>                </div>
                
          <div class="right">
                	<p>Pellentesque magna diam, mattis porttitor aliquam nec, hendrerit ac eros. Duis facilisis, nibh ut mollis pulvinar, eros felis rutrum turpis, vitae rhoncus erat dolor vitae velit. Cras facilisis pretium lacus, vel volutpat metus convallis sagittis. <a href="#">Aenean</a> augue risus, fermentum id bibendum rhoncus, lobortis et risus</p>
			  </div>
                
                <div class="cleaner"></div>
            </div>
            
            

        </div>
        
         <div class="services_section">
        
            <h4>Maecenas eleifend arcu eget </h4>
            
			<div class="services_content">
            
            	<div class="left">
                	<a href="#"><img src="<?php echo Kohana::$base_url ?>assets/themes/business/images//service_02.png" alt="image" /></a>                </div>
                
          <div class="right">
                
                	<p>Maecenas eleifend arcu eget erat mollis ullamcorper quis a tellus. Vestibulum erat mauris, volutpat auctor scelerisque in, bibendum sit amet metus. Sed hendrerit, libero eu sagittis scelerisque, libero augue accumsan lacus, quis auctor eros metus non ligula. Aliquam erat volutpat. <a href="#">Maecenas</a> eget nisl id nisi consequat ultrices et eu nunc.</p>
              </div>
                
                <div class="cleaner"></div>
            </div>
        </div>
        
        <div class="services_section">
        
            <h4>Nunc porttitor feugiat elit</h4>

            <div class="services_content">
            
            	<div class="left">
                	<a href="#"><img src="<?php echo Kohana::$base_url ?>assets/themes/business/images//service_03.png" alt="image" /></a>                </div>
                
          <div class="right">
                
                	<p>Duis et leo elit, et aliquam turpis. In egestas justo at nulla mattis non commodo nulla sodales. Pellentesque vehicula rutrum ante, at euismod mauris dignissim commodo. Nullam vel ligula elit. <a href="#">Quisque</a> ornare interdum aliquet. Praesent laoreet dignissim justo sed consequat. Mauris placerat posuere leo eget facilisis. Pellentesque eget congue lacus.</p>
              </div>
                
                <div class="cleaner"></div>
            </div>
        </div>
            
<?php echo View::factory('footer') ?>