<?php echo View::factory('header') ?>
    
        <div class="post_section">
        
            <h2> Nulla dapibus lectus ut nulla</h2>
            
            May 24th in <a href="http://www.cssmoban.com" target="_parent">Web Template</a> by <a href="http://www.cssmoban.com" target="_parent">网页模板</a>
            
      <div class="post_content">
            
            	<div class="left">
               		<img src="<?php echo Kohana::$base_url ?>assets/themes/business/images//templatemo_image_01.jpg" alt="image" />
                </div>
                
                <div class="right">
                	<p>Curabitur mollis mi non elit mollis sit amet sodales lectus tempor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Praesent eu erat neque. Nullam consequat ipsum at tellus ultrices bibendum.</p>
                    
                  <a href="#">Continue reading...</a> | <a href="subpage.html">Comments (36)</a>
                </div>
                
                <div class="cleaner"></div>
            </div>
            
            

        </div>
        
  <div class="post_section">
        
            <h2>Lorem ipsum dolor sit amet</h2>
            
            May 24th in <a href="http://www.cssmoban.com" target="_parent">Web Template</a> by <a href="http://www.cssmoban.com" target="_parent">网页模板</a>
            
            <div class="post_content">
            
            	<div class="left">
                	<img src="<?php echo Kohana::$base_url ?>assets/themes/business/images//templatemo_image_02.jpg" alt="image" />
                </div>
                
                <div class="right">
                
                	<p>Nullam consequat ipsum at tellus ultrices bibendum. Donec elit orci, semper malesuada lacinia non, interdum nec lorem. Donec sagittis venenatis magna, vitae scelerisque nibh elementum iaculis. Sed ipsum urna, rhoncus at elementum eu, bibendum at nisl. Maecenas libero massa, lobortis at aliquam at, convallis bibendum odio. Aliquam molestie felis non ipsum scelerisque.</p>
                    
                    <a href="#">Continue reading...</a> | <a href="subpage.html">Comments (68)</a>
                </div>
                
                <div class="cleaner"></div>
            </div>
        </div>
        
        <div class="post_section">
        
            <h2>Sed fringilla faucibus sem quis</h2>
            
            May 24th in <a href="http://www.cssmoban.com" target="_parent">Web Template</a> by <a href="http://www.cssmoban.com" target="_parent">网页模板</a>
            
      <div class="post_content">
            
            	<div class="left">
                	<img src="<?php echo Kohana::$base_url ?>assets/themes/business/images//templatemo_image_03.jpg" alt="image" />
                </div>
                
                <div class="right">
                
                	<p> Proin ac magna justo, in dapibus diam. In hac habitasse platea dictumst. Quisque eu sodales diam. Vestibulum semper, arcu et eleifend ullamcorper, mi nibh pellentesque quam, a porta nulla mauris eu tortor. Aenean imperdiet mattis magna nec ultrices.</p>
                    
                  <a href="#">Continue reading...</a> | <a href="subpage.html">Comments (78)</a>
                </div>
                
                <div class="cleaner"></div>
            </div>
        </div>
        
<?php echo View::factory('footer') ?>