<?php defined('SYSPATH') or die('No direct script access.');

	$_common['err_cannot_empty']      = 'Required field';
	
	$_common['msg_feeback_success']   = 'Send Success!';
	$_common['msg_feeback_fail']      = "Error: Email and Content Can't empty!";
	return $_common;